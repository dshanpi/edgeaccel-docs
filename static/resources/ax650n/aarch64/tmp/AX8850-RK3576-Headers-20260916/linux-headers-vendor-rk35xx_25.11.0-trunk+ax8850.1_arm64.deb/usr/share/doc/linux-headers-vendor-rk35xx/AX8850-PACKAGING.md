# Local AX8850 headers correction

Based on Armbian linux-headers-vendor-rk35xx 25.11.0-trunk.
Locally maintained adaptation for the exact DShanPi-A1 kernel identified below.
The original kernel/header licensing continues to apply.

Fix: declare pahole >= 1.25; use the running kernel configuration and matching
generated headers; prepare native ARM64 kbuild helpers before packaging.
Package configuration validates files and target identity without olddefconfig,
so a missing tool cannot silently turn off CONFIG_DEBUG_INFO_BTF_MODULES.
No AXCL module, kernel Image, PAC, AXP, firmware or bootloader is installed.

External build of all seven AXCL 3.16 modules succeeded in an isolated directory.
New modules were inspected, not loaded. Full package installation is pending the
owner's manual installation; this package is not a general rk35xx kernel update.

{
  "kernel_release": "6.1.115-vendor-rk35xx",
  "image_sha256": "68fbb255175f1bd758672b1e8bf88b1e8b7aa9f61d37d891712f2efe5d8d33a5",
  "running_config_sha256": "bd6e9db8dc43a68f7ea5f8423f00c66765cdd93d3b23b4842713c64626e26911",
  "base_deb_sha256": "8cbba4243297b94f76c555dc8e339eabe340ee4b3f76fdf1220b6f6dcab79bb2"
}

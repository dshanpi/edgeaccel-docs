"""Run the fixed official SenseVoice frontend and decoder with AXCL."""
import argparse,json,sys,time,hashlib
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--language',choices=['auto','en','zh','yue','ja','ko'],default='auto');p.add_argument('--streaming',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=a.model_dir.resolve();manifest=json.loads((Path(__file__).parent/'download-manifest.json').read_text('utf-8'))
for f in manifest['files']:
 if f['path'].startswith('python/'):
  assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['verifiedHashes']['sha256'],f['path']
sys.dont_write_bytecode=True;sys.path.insert(0,str(root/'python'))
from SenseVoiceAx import SenseVoiceAx
import librosa
base=root/'sensevoice_ax650'
model=SenseVoiceAx(str(base/('streaming_sensevoice.axmodel' if a.streaming else 'sensevoice.axmodel')),str(base/'am.mvn'),str(base/'tokens.txt'),str(base/'chn_jpn_yue_eng_ko_spectok.bpe.model'),max_seq_len=26 if a.streaming else 256,beam_size=3,hot_words=None,streaming=a.streaming,providers=['AXCLRTExecutionProvider'])
try:
 assert model.model.get_providers()=='AXCLRTExecutionProvider'
 wave,sr=librosa.load(str(a.input.resolve()),sr=16000);start=time.perf_counter();updates=[]
 if a.streaming:
  samples=(wave*32768).tolist()
  for i in range(0,len(samples),1600):
   for result in model.stream_infer(samples[i:i+1600],i+1600>=len(samples),a.language):
    updates.append(result);print(result['text'],flush=True)
  assert updates;answer=updates[-1]['text']
 else:answer=model.infer((wave,sr),a.language)
 seconds=time.perf_counter()-start;duration=len(wave)/sr
 result=dict(provider='AXCLRTExecutionProvider',input=str(a.input.resolve()),language=a.language,streaming=a.streaming,transcript=answer,seconds=seconds,durationSeconds=duration,rtf=seconds/duration,streamUpdates=updates)
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
finally:
 model.model._sess._unload();model.model._sess._unload=lambda:None

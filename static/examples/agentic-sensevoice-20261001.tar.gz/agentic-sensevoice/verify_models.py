"""Verify exactly the model files used by this fixed deployment example."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--model-dir',required=True,type=Path);a=p.parse_args();root=a.model_dir.resolve()
m=json.loads((Path(__file__).resolve().parent/'download-manifest.json').read_text('utf-8'));assert m['complete'] and len(m['files'])==14
for f in m['files']:
 path=(root/f['path']).resolve();assert path.is_relative_to(root) and path.stat().st_size==f['size'],f['path']
 with path.open('rb') as s:assert hashlib.file_digest(s,'sha256').hexdigest()==f['verifiedHashes']['sha256'],f['path']
print('Verified 14 model files')

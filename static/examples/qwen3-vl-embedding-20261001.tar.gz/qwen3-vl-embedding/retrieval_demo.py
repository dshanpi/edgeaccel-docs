"""Query local AX-LLM embeddings and save actual bilingual image rankings."""
import argparse,json,math,time,urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--api',default='http://127.0.0.1:3611');p.add_argument('--images',type=Path,required=True);p.add_argument('--output',type=Path,default=Path('retrieval-result.json'));a=p.parse_args()
images=[(a.images/n).resolve() for n in ['bird.jpg','cat.jpg','dog-chai.jpeg']]
assert all(f.is_file() for f in images)
http=urllib.request.build_opener(urllib.request.ProxyHandler({}));records=[]
def embed(parts):
 body={'model':'AXERA-TECH/Qwen3-VL-Embedding-2B','messages':[{'role':'system','content':[{'type':'text','text':"Represent the user's input."}]},{'role':'user','content':parts}],'encoding_format':'float'}
 request=urllib.request.Request(a.api.rstrip('/')+'/v1/embeddings',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'});start=time.perf_counter()
 with http.open(request,timeout=180) as response:result=json.load(response)
 v=result['data'][0]['embedding'];norm=math.sqrt(sum(x*x for x in v));assert len(v)==2048 and all(math.isfinite(x) for x in v) and abs(norm-1)<1e-4
 records.append({'request':body,'response':result,'seconds':time.perf_counter()-start,'dimensions':len(v),'norm':norm});return [x/norm for x in v]
vectors=[embed([{'type':'image_url','image_url':{'url':str(f)}}]) for f in images];rankings=[]
for text in ['a bird','a cat','a dog','一只鸟','一只猫','一只狗']:
 v=embed([{'type':'text','text':text}]);scores=[sum(x*y for x,y in zip(v,img)) for img in vectors];order=sorted(range(3),key=lambda i:scores[i],reverse=True)
 row={'text':text,'scores':dict(zip([f.name for f in images],scores)),'ranking':[images[i].name for i in order]};rankings.append(row);print(text,[(images[i].name,round(scores[i],4)) for i in order])
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps({'requests':records,'rankings':rankings},ensure_ascii=False,indent=2),encoding='utf-8');print('Saved',a.output)

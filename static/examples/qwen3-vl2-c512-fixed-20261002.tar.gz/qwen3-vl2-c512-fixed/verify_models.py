from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve();m=json.loads(Path(__file__).with_name('download-manifest.json').read_text())
for item in m['files']:
 p=(root/item['path']).resolve();assert p.is_relative_to(root) and p.stat().st_size==item['size'],item['path']
 with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 assert digest==item['verifiedHashes']['sha256'],item['path']
print('Verified 34 model files')

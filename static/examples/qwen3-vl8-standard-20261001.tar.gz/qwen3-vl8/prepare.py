"""Prepare the fixed standard Qwen3-VL-8B model for interactive AXCL inference."""
import argparse,json,shlex,sys,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--python',default=sys.executable);a=p.parse_args()
root=a.model_dir.resolve();out=a.output.resolve();package=Path(__file__).resolve().parent;weight='Qwen3-VL-8B-Instruct-AX650-c128_p1152';binary=package/'bin/main'
required=[root/weight/('qwen3_vl_text_p128_l%d_together.axmodel'%i) for i in range(36)]+[root/weight/n for n in ['qwen3_vl_text_post.axmodel','Qwen3-VL-8B-Instruct_vision.axmodel','model.embed_tokens.weight.bfloat16.bin']]+[root/'post_config.json',root/'qwen3-vl-tokenizer/tokenizer_config.json',root/'qwen3-vl-tokenizer/tokenizer.json',root/'qwen3-vl-tokenizer/vocab.json',root/'qwen3-vl-tokenizer/merges.txt',binary]
for path in required:
 if not path.is_file() or not path.stat().st_size:raise SystemExit('Missing file: '+str(path))
proof=json.loads((package/'tokenizer-export.json').read_text());assert hashlib.sha256((package/'qwen3_tokenizer.txt').read_bytes()).hexdigest()==proof['tokenizerSha256']
assert all(hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in proof['inputFiles'])
post=json.loads((root/'post_config.json').read_text());post.update(enable_temperature=False,enable_repetition_penalty=False,enable_top_p_sampling=False,enable_top_k_sampling=True,top_k=1)
out.mkdir(parents=True,exist_ok=False);(out/weight).symlink_to(root/weight,target_is_directory=True)
for n in ['images','video']:(out/n).symlink_to(package/n,target_is_directory=True)
(out/'post_config.json').write_text(json.dumps(post,indent=2),'utf-8')
base=[str(binary),'--template_filename_axmodel',weight+'/qwen3_vl_text_p128_l%d_together.axmodel','--axmodel_num','36','--filename_image_encoder_axmodedl',weight+'/Qwen3-VL-8B-Instruct_vision.axmodel','--use_mmap_load_embed','0','--filename_tokenizer_model',str(package/'qwen3_tokenizer.txt'),'--filename_post_axmodel',weight+'/qwen3_vl_text_post.axmodel','--filename_tokens_embed',weight+'/model.embed_tokens.weight.bfloat16.bin','--tokens_embed_num','151936','--tokens_embed_size','4096','--patch_size','16','--live_print','0','--img_width','384','--img_height','384','--vision_start_token_id','151652','--post_config_path','post_config.json','--devices','0,']
for name,flag in [('image','0'),('video','1')]:
 cmd=base+['--video',flag];script='#!/usr/bin/env bash\nset -euo pipefail\ncd -- '+shlex.quote(str(out))+'\nexport OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1\nexec 9>.inference.lock\nflock -n 9 || { echo "Another inference session is running." >&2; exit 1; }\nexec '+shlex.join(cmd)+'\n';(out/('run_'+name+'.sh')).write_text(script,'utf-8')
print('Created',out);print('Images: bash',out/'run_image.sh');print('Video frames: bash',out/'run_video.sh')

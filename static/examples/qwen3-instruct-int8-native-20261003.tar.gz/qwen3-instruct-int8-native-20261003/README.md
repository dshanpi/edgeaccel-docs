# Qwen3-4B-Instruct-2507-GPTQ-Int8 ARM64 AXCL runner

For the fixed AXERA-TECH model revision b334419218b9640ae78ae163ba484eb587589a8f, device 0, 36 layers, 256-token prefill chunks and 3584-token maximum prompt including the chat template.

This site-maintained runner derives from AXERA-TECH/ax-llm source revision 3be4cc3fee4a4c730ec7c9b8982ff4b398eefac7. It uses the unchanged official compiled model weights with a native tokenizer and a text-only entry point. See upstream.json, the inherited changes, source-preparation.json and adaptation.diff. The official model weight files must be downloaded separately.

Runtime: ARM64 Ubuntu 24.04, AXCL 3.16, OpenCV 4.6, PCRE2 and ICU 74. Other systems should rebuild from source; do not replace their shared libraries with symlinks. Install cmake g++ libopencv-dev libpcre2-dev libicu-dev, extract source.tgz and run:

    cmake -S source -B build -DCMAKE_BUILD_TYPE=Release -DTOKENIZER_BUILD_TESTS=OFF
    cmake --build build --target main --parallel 1
    cp build/main runtime/main_axcl_aarch64

Supply a UTF-8 prompt file without an extra newline. Run `bash runtime/run.sh MODEL_DIR PROMPT_FILE OUTPUT_JSON`. Each invocation is one independent question and does not retain conversation history. The result file contains the raw answer, exact input/output token IDs, EOS and wall-clock timing. Original license files are included in source.tgz.

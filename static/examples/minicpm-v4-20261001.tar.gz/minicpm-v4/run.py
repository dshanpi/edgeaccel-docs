"""Run the fixed official MiniCPM-V-4 entry point on the AXCL provider."""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
import argparse,hashlib,sys,types
from pathlib import Path
import torch,axengine
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--model-dir',type=Path,required=True);a,extra=p.parse_known_args()
root=a.model_dir.resolve();source=root/'run_axmodel.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='abaf391aa731bea9ed9f58dd41e11caae66a323cadd0d605ee41ea3ede5ee041'
original_session=axengine.InferenceSession;original_load=torch.load;sessions=[];tokens=[]
def session(path,*args,**kwargs):
 kwargs['providers']=['AXCLRTExecutionProvider'];s=original_session(path,*args,**kwargs)
 assert s.get_providers()=='AXCLRTExecutionProvider';sessions.append((Path(path).name,s));return s
def load(path,*args,**kwargs):
 assert Path(path).resolve()==root/'embed_tokens.pth';kwargs.update(weights_only=True,map_location='cpu')
 with torch.serialization.safe_globals([torch.nn.Embedding,set]):result=original_load(path,*args,**kwargs)
 assert isinstance(result,torch.nn.Embedding) and list(result.weight.shape)==[73448,2560];return result
def close(s):
 inner=s._sess;inner._unload();inner._unload=lambda:None
sys.dont_write_bytecode=True
text=source.read_text();marker="if  __name__ == '__main__':";assert text.count(marker)==1
definitions,entry=text.split(marker);ns={'__name__':'minicpm_official_pinned','__file__':str(source)}
exec(compile(definitions,str(source),'exec'),ns);ns['ort']=types.SimpleNamespace(InferenceSession=session)
post=ns['post_process'];decode=ns['MiniCPMV']._decode
def capture(data,*args,**kwargs):
 result=post(data,*args,**kwargs);tokens.append(int(result[0]));return result
def decode_with_release(self,*args,**kwargs):
 for name,s in sessions:
  if name in ['siglip.axmodel','resampler.axmodel']:close(s)
 return decode(self,*args,**kwargs)
ns['post_process']=capture;ns['MiniCPMV']._decode=decode_with_release;ns['__name__']='__main__';torch.load=load
sys.argv=[str(source),'--hf_model_path',str(root/'minicpmv4_tokenizer'),'--siglip_axmodel',str(root/'siglip.axmodel'),'--resampler_axmodel',str(root/'resampler.axmodel'),'--embed_token_path',str(root/'embed_tokens.pth'),'--minicpm_axmodel',str(root/'minicpm-v-4_axmodel'),*extra]
try:
 exec(compile(marker+entry,str(source),'exec'),ns)
 print('\n[完整回答]\n'+ns['tokenizer'].decode(tokens,skip_special_tokens=True))
 print('[结束 token]',tokens[-1] if tokens else None)
finally:
 torch.load=original_load
 for _,s in sessions:close(s)

"""Verify every file of the fixed official model download (Python 3.9+)."""
import argparse, hashlib, json, sys
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model_dir", type=Path)
    args = parser.parse_args()
    root = args.model_dir.expanduser().resolve(strict=True)
    manifest = json.loads(Path(__file__).with_name("download-manifest.json").read_text(encoding="utf-8"))
    if manifest["revision"] != "97ccbbde2f2282a24ff00bb5df8e5c9eb34033fb" or len(manifest["files"]) != 49:
        raise ValueError("Unexpected model manifest")
    for entry in manifest["files"]:
        file = (root / entry["path"]).resolve(strict=True)
        if not file.is_relative_to(root) or not file.is_file():
            raise ValueError("Invalid model path: " + entry["path"])
        if file.stat().st_size != entry["size"]:
            raise ValueError("Size mismatch: " + entry["path"])
        digest = hashlib.sha256()
        with file.open("rb") as stream:
            for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
                digest.update(block)
        if digest.hexdigest() != entry["verifiedHashes"]["sha256"]:
            raise ValueError("SHA256 mismatch: " + entry["path"])
    print("Verified 49 model files; revision " + manifest["revision"])

if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as error:
        sys.exit("Verification failed: " + str(error))

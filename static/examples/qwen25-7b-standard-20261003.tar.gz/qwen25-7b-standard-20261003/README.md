# Qwen2.5-7B-Instruct 文件校验

本工具包只包含固定版本文件清单和 Python 3.9+ 校验脚本，不包含模型或推理程序。下载对应版本后运行 `python3 verify_models.py MODEL_DIR`，确认 49 个文件校验通过。

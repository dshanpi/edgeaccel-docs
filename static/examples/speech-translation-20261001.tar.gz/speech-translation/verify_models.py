"""Check the exact application and companion files used by the guide."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--app-dir',type=Path,required=True);p.add_argument('--companion-dir',type=Path,required=True);a=p.parse_args()
for directory,name in [(a.app_dir,'download-manifest.json'),(a.companion_dir,'companion-manifest.json')]:
 root=directory.resolve();manifest=json.loads((Path(__file__).parent/name).read_text())
 for f in manifest['files']:
  file=(root/f['path']).resolve();assert file.is_relative_to(root) and file.is_file() and file.stat().st_size==f['size'],f['path']
  with file.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==f['verifiedHashes']['sha256'],f['path']
 print('Verified',len(manifest['files']),'files:',manifest['modelId'],manifest['revision'])

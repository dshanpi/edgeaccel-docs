"""Run the pinned official file pipeline with explicit M.2 card execution."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',NO_PROXY='127.0.0.1,localhost',no_proxy='127.0.0.1,localhost')
import argparse,hashlib,importlib.util,importlib.abc,importlib.machinery,json,sys,tempfile,time
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--app-dir',type=Path,required=True);p.add_argument('--audio',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 root=a.app_dir.resolve();audio=a.audio.resolve();out=a.output.resolve();assert audio.is_file();out.mkdir(parents=True,exist_ok=False)
 manifest=json.loads((Path(__file__).parent/'download-manifest.json').read_text());expected={f['path']:f for f in manifest['files']}
 def sha(path):
  with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
 def verify():
  for name,f in expected.items():
   path=(root/name).resolve();assert path.is_relative_to(root) and path.stat().st_size==f['size'] and sha(path)==f['verifiedHashes']['sha256'],name
 verify()
 entries={'Speech-Translation.axera':'ax_speech_translate_demo_qwen_api.py','Spoken-Communication.axera':'ax_spoken_communication_demo.py'};entry=entries[manifest['modelId']]
 import axengine,numpy as np,torch,librosa,soundfile as sf,requests
 torch.manual_seed(42);np.random.seed(42);original=axengine.InferenceSession;active=[]
 def session(path,*args,**kwargs):
  kwargs['providers']=['AXCLRTExecutionProvider'];value=original(path,*args,**kwargs);providers=value.get_providers();assert 'AXCLRTExecutionProvider' in providers;active.append(value);return value
 english=root/'libmelotts/python/text/english.py'
 with tempfile.TemporaryDirectory(prefix='speech-cmu-') as cache:
  class Loader(importlib.abc.Loader):
   def create_module(self,spec):return None
   def exec_module(self,module):
    source=english.read_text();old='CACHE_PATH = "/tmp/cmudict_cache.pickle"';assert source.count(old)==1
    source=source.replace(old,'CACHE_PATH = '+repr(str(Path(cache)/'cmudict.pickle')));module.__file__=str(english);exec(compile(source,str(english),'exec'),module.__dict__)
  class Finder(importlib.abc.MetaPathFinder):
   def find_spec(self,fullname,path=None,target=None):
    if fullname=='libmelotts.python.text.english':return importlib.machinery.ModuleSpec(fullname,Loader(),origin=str(english))
  finder=Finder();sys.meta_path.insert(0,finder);sys.path.insert(0,str(root));sys.dont_write_bytecode=True;os.chdir(root);axengine.InferenceSession=session
  try:
   http=requests.Session();http.trust_env=False;response=http.post('http://127.0.0.1:8000/api/reset',json={},timeout=15);response.raise_for_status()
   spec=importlib.util.spec_from_file_location('official_speech_application',root/entry);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
   speech,rate=librosa.load(audio,sr=None)
   if rate!=16000:speech=librosa.resample(y=speech,orig_sr=rate,target_sr=16000);rate=16000
   pipeline=module.SpeechTranslationPipeline(tts_model_dir=str(root/module.TTS_MODEL_DIR),tts_model_files=module.TTS_MODEL_FILES,asr_model_dir=str(root/'ax_model'),seq_len=132,tts_dec_len=128,sample_rate=44100,tts_speed=0.8,qwen_api_url='http://127.0.0.1:8000')
   start=time.perf_counter();result=pipeline.full_pipeline(speech,rate,str(out),'synthesized.wav');seconds=time.perf_counter()-start
   assert result['original_text'].strip() and result['translated_text'].strip()
   assert not any(x in result['translated_text'] for x in ['翻译失败:','翻译超时','失败:','超时，请检查API服务状态'])
   path=Path(result['audio_path']).resolve();assert path.is_relative_to(out);samples,sr=sf.read(path,dtype='float32');assert samples.size and sr==44100 and np.isfinite(samples).all() and np.max(np.abs(samples))>0
   result.update(modelId=manifest['modelId'],revision=manifest['revision'],inputFile=str(audio),requestSeconds=seconds,audioSha256=sha(path),sampleRate=sr)
   (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
  finally:
   for value in active:
    inner=value._sess;inner._unload();inner._unload=lambda:None
   axengine.InferenceSession=original;sys.meta_path.remove(finder);verify()
if __name__=='__main__':main()

"""Run a fixed Qwen3-VL-4B image or JPEG-frame question on ARM64 AXCL."""
from pathlib import Path
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('mode',choices=['image','video']);p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--prompt',required=True);p.add_argument('--dry-run',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parent;model=a.model_dir.resolve();media=a.input.resolve()
assert a.prompt.strip() and '\n' not in a.prompt and '\r' not in a.prompt and '\n' not in str(media)
for name,digest in {'main_axcl_aarch64': '5fe013816dace0fa1f9a2433cb809d6112c152b0b5a7ecfa424615707000cab6', 'qwen3_tokenizer.txt': 'ee94c32896590639b7fdcfcdeed48e2556ce0115148dddb1da838fa0349a4b6c', 'post-greedy.json': '1ec79ac41edf027ec2f66be740bb7f4c2c1188edd1ddd8e16922068dba61938f'}.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
if a.mode=='image':assert media.is_file()
else:
 if not media.is_dir():p.error('Video input must be an ordered JPEG directory')
 frames=sorted(media.iterdir())
 if len(frames) not in [3,8] or not all(x.is_file() and x.suffix.lower()=='.jpg' for x in frames):p.error('Use the three-frame official sample or eight-frame companion at 1 fps')
cmd=['./main_axcl_aarch64','--template_filename_axmodel',str(model/'qwen3_vl_text_p128_l%d_together.axmodel'),'--axmodel_num','36','--filename_image_encoder_axmodedl',str(model/'Qwen3-VL-4B-Instruct_vision.axmodel'),'--use_mmap_load_embed','0','--filename_tokenizer_model',str(root/'qwen3_tokenizer.txt'),'--filename_post_axmodel',str(model/'qwen3_vl_text_post.axmodel'),'--filename_tokens_embed',str(model/'model.embed_tokens.weight.bfloat16.bin'),'--tokens_embed_num','151936','--tokens_embed_size','2560','--live_print','0','--video','1' if a.mode=='video' else '0','--img_width','384','--img_height','384','--vision_start_token_id','151652','--post_config_path',str(root/'post-greedy.json'),'--devices','0','--temporal_patch_size','2','--spatial_merge_size','2','--patch_size','16','--fps','1','--tokens_per_second','2']
stdin=a.prompt+'\n'+str(media)+'\nq\n'
if a.dry_run:print(json.dumps(dict(command=cmd,stdin=stdin),ensure_ascii=False));raise SystemExit(0)
raise SystemExit(subprocess.run(cmd,input=stdin,text=True,encoding='utf-8',cwd=root,timeout=650).returncode)

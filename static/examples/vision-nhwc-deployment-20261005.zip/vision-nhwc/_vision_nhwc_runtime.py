"""Explicit AXCL adapter for the pinned small-vision preprocessing plans.

This program is prepared for future board testing, not evidence of a completed run.
The controller must check card health before starting and after collecting outputs.
"""
import argparse,datetime,hashlib,json,os,platform,runpy,sys,time,types
from pathlib import Path

def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--models-root',type=Path,required=True)
    p.add_argument('--plan',type=Path,required=True)
    p.add_argument('--io',type=Path,required=True)
    p.add_argument('--case',required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--expected-boot',required=True)
    p.add_argument('--reverse-channels',action='store_true',help='Explicit RGB/BGR contrast; never silently selects a color order')
    a=p.parse_args()
    assert platform.machine() in ['aarch64','arm64'],'Board execution only'
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    assert boot==a.expected_boot and boot!='feac3838-e1c6-42d2-a11a-005f5a786039','Fresh verified boot required'
    plan=json.loads(a.plan.read_text('utf-8'))
    case=next(c for c in plan['cases'] if c['case']==a.case)
    base=(a.models_root/case['modelId']).resolve()
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    assert not out.is_relative_to(base),'Results must be outside the original repository'
    io=json.loads(a.io.read_text('utf-8'))['cases']
    source=next(c for c in io if c['modelId']==case['modelId'] and c['path']==case['sourceModel'])
    target=next(c for c in io if c['modelId']==case['modelId'] and c['path']==case['targetModel'])
    assert case['revision']==source['revision']==target['revision']
    for name,expected in [(case['script'],case['scriptSha256']),(case['fixture'],case['fixtureSha256']),(case['targetModel'],target['sha256'])]:
        file=(base/name).resolve();assert file.is_relative_to(base) and digest(file)==expected
    import cv2,numpy as np,axengine
    real_session=axengine.InferenceSession
    original_imwrite=cv2.imwrite
    record={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bootId':boot,
            'case':case,'targetSha256':target['sha256'],'reverseChannels':a.reverse_channels,
            'provider':'AXCLRTExecutionProvider','calls':[],'outputs':[],'deploymentAccepted':False,
            'adapterSha256':digest(Path(__file__)),'numpyVersion':np.__version__,'opencvVersion':cv2.__version__}
    def save():
        (out/'result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    class Session:
        def __init__(self,requested,*args,**kwargs):
            if isinstance(requested,list):assert len(requested)==1;requested=requested[0]
            assert Path(requested).name==Path(case['sourceModel']).name
            self.real=real_session(str(base/case['targetModel']),providers=['AXCLRTExecutionProvider'])
            inputs=self.real.get_inputs();outputs=self.real.get_outputs()
            assert len(inputs)==1 and inputs[0].name==target['inputs'][0]['name']
            assert list(inputs[0].shape)==target['inputs'][0]['shape'] and np.dtype(inputs[0].dtype)==np.uint8
            assert [(x.name,list(x.shape)) for x in outputs]==[(x['name'],x['shape']) for x in target['outputs']]
        def get_inputs(self):return [types.SimpleNamespace(**x) for x in source['inputs']]
        def get_outputs(self):return self.real.get_outputs()
        def run(self,names,feed,*args,**kwargs):
            assert list(feed)==[source['inputs'][0]['name']]
            original=np.asarray(next(iter(feed.values())))
            assert original.dtype==np.uint8 and list(original.shape)==source['inputs'][0]['shape']
            value=original.transpose(0,2,3,1) if original.shape[1]==3 else original
            if a.reverse_channels:value=value[...,::-1]
            value=np.ascontiguousarray(value)
            assert list(value.shape)==target['inputs'][0]['shape']
            number=len(record['calls']);ip=out/f'input-{number}.npy';np.save(ip,value)
            call={'input':ip.name,'inputSha256':digest(ip),'inputShape':list(value.shape)}
            record['calls'].append(call);save()
            start=time.perf_counter()
            values=self.real.run(names,{target['inputs'][0]['name']:value})
            call['wallMs']=(time.perf_counter()-start)*1000
            assert len(values)==len(target['outputs'])
            for result,meta in zip(values,target['outputs']):
                assert list(result.shape)==meta['shape'] and np.isfinite(result).all()
            op=out/f'raw-outputs-{number}.npz';np.savez(op,**{f'output{i}':v for i,v in enumerate(values)})
            call.update(output=op.name,outputSha256=digest(op),returned=True);save()
            return values
    def imwrite(name,value,*args):
        destination=out/Path(name).name
        assert not destination.exists(),'Refusing to replace an output'
        okay=original_imwrite(str(destination),value,*args)
        assert okay,'Failed to save visualization'
        record['outputs'].append({'path':destination.name,'sha256':digest(destination),'shape':list(value.shape)})
        save();return okay
    # Preserve the real package so its lazy relative backend imports still work.
    axengine.InferenceSession=Session;cv2.imwrite=imwrite
    previous=Path.cwd();previous_argv=sys.argv
    try:
        save();os.chdir(base);sys.argv=case['argv']
        runpy.run_path(str(base/case['script']),run_name='__main__')
        assert record['calls'] and all(c.get('returned') for c in record['calls'])
        record['status']='inference-completed-awaiting-effect-and-health-review'
    except BaseException as exc:
        record['status']='failed';record['error']=repr(exc);raise
    finally:
        os.chdir(previous);sys.argv=previous_argv;cv2.imwrite=original_imwrite;axengine.InferenceSession=real_session
        record['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        record['bootIdAfter']=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        save()

if __name__=='__main__':main()

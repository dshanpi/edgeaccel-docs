"""Run pinned official NHWC vision samples through the AXCL backend."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys

def main():
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'bundle-manifest.json').read_text('utf-8'))
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case',choices=manifest['cases'],required=True)
    parser.add_argument('--models-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    a=parser.parse_args()
    for file,digest in manifest['files'].items():
        assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,f'Package file differs: {file}'
    if a.output.exists():parser.error('Output directory already exists; choose a new directory.')
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    command=[sys.executable,str(root/'_vision_nhwc_runtime.py'),'--models-root',str(a.models_root.resolve()),
             '--plan',str(root/'plan.json'),'--io',str(root/'io.json'),'--case',manifest['cases'][a.case],
             '--output',str(a.output.resolve()),'--expected-boot',boot]
    return subprocess.run(command,check=False).returncode

if __name__=='__main__':sys.exit(main())

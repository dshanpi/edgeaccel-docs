"""Launch the unmodified, pinned official LocateAnything script with an explicit AXCL provider."""
import argparse,hashlib,runpy,sys
from pathlib import Path
import axengine

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--model-dir',required=True,type=Path)
a,extra=p.parse_known_args();root=a.model_dir.resolve();source=root/'infer_locateanything_axengine.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='e2958026493e7c8366261c35101955df763e8dffddde87aee3229380d1c68e79','Official source file does not match the fixed version'
original=axengine.InferenceSession
def session(path,*args,**kwargs):
 kwargs['providers']=['AXCLRTExecutionProvider']
 result=original(path,*args,**kwargs)
 assert result.get_providers()=='AXCLRTExecutionProvider'
 return result
axengine.InferenceSession=session
sys.dont_write_bytecode=True
sys.argv=[str(source),'--tokenizer',str(root/'qwen2.5_tokenizer/tokenizer.json'),'--llm-dir',str(root),'--image-encoder',str(root/'image_encoder_mlp.axmodel'),*extra]
runpy.run_path(str(source),run_name='__main__')

"""Save raw local AX-LLM text/image chat requests and responses."""
import argparse,json,time,urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--api',default='http://127.0.0.1:3612');p.add_argument('--text',required=True);p.add_argument('--image',type=Path);p.add_argument('--history',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
messages=[{'role':'system','content':'you are a helpful assistant.'}]
if a.history:
 previous=json.loads(a.history.read_text('utf-8'));messages=previous['request']['messages']+[{'role':'assistant','content':previous['response']['choices'][0]['message']['content']}]
parts=[]
if a.image:
 image=a.image.resolve();assert image.is_file();parts.append({'type':'image_url','image_url':{'url':str(image)}})
parts.append({'type':'text','text':a.text});messages.append({'role':'user','content':parts})
body={'model':'AXERA-TECH/Qwen3.5-2B','messages':messages,'stream':False,'max_tokens':512,'temperature':0.0,'top_p':1.0};http=urllib.request.build_opener(urllib.request.ProxyHandler({}));start=time.perf_counter()
request=urllib.request.Request(a.api.rstrip('/')+'/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
with http.open(request,timeout=240) as response:result=json.load(response)
record={'request':body,'response':result,'seconds':time.perf_counter()-start};a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
reply=result['choices'][0]['message']['content']
if reply.lstrip().startswith('<think>'):
 if '</think>' not in reply:raise SystemExit('Incomplete response: thinking segment did not close. Raw response saved to '+str(a.output))
 reply=reply.split('</think>',1)[1].strip()
if not reply:raise SystemExit('Empty final answer. Raw response saved to '+str(a.output))
print(reply);print('Saved raw response',a.output)

"""Run the fixed standard Qwen2.5-VL-3B AXCL configuration."""
from pathlib import Path
import argparse,hashlib,json,subprocess

p=argparse.ArgumentParser()
p.add_argument('mode',choices=['image','video'])
p.add_argument('--model-dir',type=Path,required=True)
p.add_argument('--input',type=Path,required=True)
p.add_argument('--prompt',required=True)
p.add_argument('--tokenizer-url',default='http://127.0.0.1:8511')
p.add_argument('--dry-run',action='store_true')
a=p.parse_args()
root=Path(__file__).resolve().parent
model=a.model_dir.resolve();media=a.input.resolve()
weights=model/'Qwen2.5-VL-3B-Instruct-AX650-chunk_prefill_512'
assert '\n' not in a.prompt and '\r' not in a.prompt and '\n' not in str(media)
assert hashlib.sha256((root/'main_axcl_aarch64').read_bytes()).hexdigest()=='b6d3cdbe0b4d9d47cb8f901a8f576cd82e7c0723fc9500cb12fae1b34f91a235'
assert hashlib.sha256((root/'post-greedy.json').read_bytes()).hexdigest()=='7cd05fda186c94658893a58b9cb4f18f4747e932ecd52f8f449ae862265078e0'
if a.mode=='image':
 assert media.is_file()
 size='448';vision='Qwen2.5-VL-3B-Instruct_vision_nchw448.axmodel'
else:
 assert media.is_dir() and len(list(media.iterdir()))==8 and all(x.suffix.lower()=='.jpg' for x in media.iterdir()),'Use the supplied eight JPEG frames'
 size='308';vision='Qwen2.5-VL-3B-Instruct_vision_nhwc.axmodel'
cmd=['./main_axcl_aarch64','--template_filename_axmodel',str(weights/'qwen2_5_vl_p128_l%d_together.axmodel'),'--axmodel_num','36','--filename_image_encoder_axmodedl',str(weights/vision),'--use_mmap_load_embed','0','--filename_tokenizer_model',a.tokenizer_url,'--filename_post_axmodel',str(weights/'qwen2_5_vl_post.axmodel'),'--filename_tokens_embed',str(weights/'model.embed_tokens.weight.bfloat16.bin'),'--tokens_embed_num','151936','--tokens_embed_size','2048','--live_print','0']
if a.mode=='video':cmd+=['--video','1']
cmd+=['--img_width',size,'--img_height',size,'--vision_start_token_id','151652','--post_config_path',str(root/'post-greedy.json'),'--devices','0']
if a.mode=='image':cmd+=['--video','0']
cmd+=['--temporal_patch_size','2','--spatial_merge_size','2','--patch_size','14','--fps','1','--tokens_per_second','2']
stdin=a.prompt+'\n'+str(media)+'\nq\n'
if a.dry_run:print(json.dumps(dict(command=cmd,stdin=stdin),ensure_ascii=False));raise SystemExit(0)
raise SystemExit(subprocess.run(cmd,input=stdin,text=True,encoding='utf-8',cwd=root,timeout=600).returncode)

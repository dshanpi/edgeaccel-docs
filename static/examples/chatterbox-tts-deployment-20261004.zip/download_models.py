from pathlib import Path
import argparse,hashlib,json,shutil
HERE=Path(__file__).resolve().parent
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--models-dir',type=Path,default=HERE/'host-models');a=p.parse_args()
    if not a.verify_only:
        from huggingface_hub import hf_hub_download
    count=0
    for repo in json.loads((HERE/'downloads.json').read_text()):
        manifest=HERE/repo['manifest'];m=json.loads(manifest.read_text());root=a.models_dir/repo['role']
        if not a.verify_only:root.mkdir(parents=True,exist_ok=True)
        for item in m['files']:
            target=root/item['path'];expected=item['verifiedHashes']['sha256']
            if not target.is_file() or sha(target)!=expected:
                if a.verify_only:raise ValueError('Missing or changed file: '+str(target))
                hf_hub_download(repo_id=m['repo'],filename=item['path'],revision=m['revision'],local_dir=root,force_download=True)
            assert target.stat().st_size==item['size'] and sha(target)==expected
            count+=1;print('Verified',repo['role'],item['path'],flush=True)
        if not a.verify_only:shutil.copy2(manifest,root/'.validation-download.json')
    print('Verified',count,'fixed model and support files')
if __name__=='__main__':main()

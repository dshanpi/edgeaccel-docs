"""Prepare authentic built-in conditioning and a CPU reference for AXERA T3.

Only preprocessing is used by the card runner. CPU logits are comparison evidence.
"""
import argparse, hashlib, importlib, json, sys, types, time
from pathlib import Path

W=Path(__file__).resolve().parent
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--text',default='Hello.');p.add_argument('--language',default='en');p.add_argument('--output',type=Path,required=True);p.add_argument('--cpu-tokens',type=int,default=0);p.add_argument('--cfg-weight',type=float,default=0);p.add_argument('--bos-count',type=int,choices=[1,2],default=2);a=p.parse_args()
    out=a.output;out.mkdir(parents=True,exist_ok=False)
    original=W/'host-models/chatterbox-t3-v3-original';card=W/'host-models/chatterbox-p192-ctx384-ax650'
    rec=dict(text=a.text,language=a.language,completed=False,originalFiles=[],embeddingChecks=[],sourceVersion='chatterbox-tts 0.1.7',scope='CPU conditioning plus reference, not card inference')
    def save():(out/'preparation.json').write_text(json.dumps(rec,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    save()
    manifest=json.loads((original/'.validation-download.json').read_text());assert manifest['complete'] and manifest['revision']=='5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18'
    for f in manifest['files']:
        d=sha(original/f['path']);assert d==f['verifiedHashes']['sha256'];rec['originalFiles'].append(dict(path=f['path'],sha256=d))
    rec['originalRevision']=manifest['revision'];save();print('Verified original files',flush=True)
    import numpy as np,torch
    from safetensors.torch import load_file
    torch.set_num_threads(4)
    # Use wheel modules without importing the unrelated TTS frontend/dependencies.
    src=W/'chatterbox-017-source/chatterbox'
    for name,rel in [('chatterbox',''),('chatterbox.models','models'),('chatterbox.models.t3','models/t3'),('chatterbox.models.t3.modules','models/t3/modules'),('chatterbox.models.t3.inference','models/t3/inference'),('chatterbox.models.tokenizers','models/tokenizers')]:
        mod=types.ModuleType(name);mod.__path__=[str(src/rel)];sys.modules[name]=mod
    from chatterbox.models.t3.t3 import T3
    from chatterbox.models.t3.modules.t3_config import T3Config
    from chatterbox.models.t3.modules.cond_enc import T3Cond
    tokenizer_module=importlib.import_module('chatterbox.models.tokenizers.tokenizer')
    def fixed_download(repo_id,filename,**kwargs):
        assert repo_id=='ResembleAI/chatterbox' and filename=='Cangjie5_TC.json';return str(original/filename)
    tokenizer_module.hf_hub_download=fixed_download
    tok=tokenizer_module.MTLTokenizer(str(original/'grapheme_mtl_merged_expanded_v1.json'))
    assert a.text.endswith(('.', '!', '?','。','！','？')), 'Provide normalized punctuation explicitly'
    ids=[255]+tok.encode(a.text,language_id=a.language)+[0];rec['textTokenIds']=ids
    state=load_file(original/'t3_mtl23ls_v3.safetensors');print('Loaded original tensors',flush=True)
    mappings={'text_embedding.float16.bin':'text_emb.weight','text_position_embedding.float16.bin':'text_pos_emb.emb.weight','speech_embedding.float16.bin':'speech_emb.weight','speech_position_embedding.float16.bin':'speech_pos_emb.emb.weight','perceiver_query_embedding.float16.bin':'cond_enc.perceiver.pre_attention_query'}
    decoded={}
    for filename,key in mappings.items():
        data=state[key].numpy();bits=np.fromfile(card/filename,dtype='<u2').reshape(data.shape)
        expected=(data.view(np.uint32)>>16).astype(np.uint16);same=int(np.count_nonzero(bits==expected));assert same==data.size,(filename,same,data.size)
        decoded[key]=(bits.astype(np.uint32)<<16).view(np.float32)
        rec['embeddingChecks'].append(dict(file=filename,key=key,elements=data.size,identicalBfloat16Truncation=same,sha256=sha(card/filename)))
    save();print('All five embeddings match V3 BF16 truncation',flush=True)
    with torch.device('meta'):model=T3(T3Config.multilingual())
    result=model.load_state_dict(state,strict=True,assign=True)
    # Rotary frequencies are nonpersistent derived buffers, absent from state_dict.
    model.tfmr.rotary_emb=type(model.tfmr.rotary_emb)(model.cfg,device='cpu')
    assert not any(v.is_meta for v in list(model.parameters())+list(model.buffers()))
    model.eval();rec['strictWeightLoad']=dict(missing=list(result.missing_keys),unexpected=list(result.unexpected_keys));save()
    conds=torch.load(original/'conds.pt',map_location='cpu',weights_only=True)
    rec['conditionShapes']={section:{k:list(v.shape) if torch.is_tensor(v) else str(v) for k,v in values.items()} for section,values in conds.items()}
    cond=T3Cond(**conds['t3']);cond.emotion_adv=torch.ones(1,1,1)*0.5
    with torch.inference_mode():ce=model.prepare_conditioning(cond).float().numpy()
    assert ce.shape[0]==1 and ce.shape[2]==1024 and np.isfinite(ce).all();np.save(out/'conditioning.npy',ce)
    text=decoded['text_emb.weight'][ids]+decoded['text_pos_emb.emb.weight'][np.arange(len(ids))]
    bos=decoded['speech_emb.weight'][6561]+decoded['speech_pos_emb.emb.weight'][0]
    # 0.1.7 inference first includes initial_speech_tokens in prepare_input_embeds,
    # then appends a second BOS with the same learned position zero.
    inp=np.concatenate([ce[0],text]+[bos[None]]*a.bos_count,axis=0)[None].astype(np.float32)
    if a.cfg_weight:
        unconditional=inp.copy();unconditional[0,ce.shape[1]:ce.shape[1]+len(ids)]=decoded['text_pos_emb.emb.weight'][np.arange(len(ids))]
        inp=np.concatenate([inp,unconditional],axis=0)
    # AXCL accepts BF16; reference sees exactly the same rounded input values.
    inp=torch.from_numpy(inp).bfloat16().float().numpy();assert inp.shape[1]<=192
    np.save(out/'input-embeddings.npy',inp)
    for k,v in conds['gen'].items():
        if torch.is_tensor(v):np.save(out/('s3gen-'+k+'.npy'),v.detach().cpu().numpy())
    rec.update(promptPositions=inp.shape[1],conditionPositions=ce.shape[1],initialSpeechBosCount=a.bos_count,cfgWeight=a.cfg_weight,alignmentAnalyzer=False)
    # Save layer states to independently check the exported graph and final norm.
    hooks=[]
    for index in (0,29):
        def hook(module,args,value,index=index):
            value=value[0] if isinstance(value,tuple) else value
            np.save(out/f'cpu-layer-{index}.npy',value.detach().float().numpy())
        hooks.append(model.tfmr.layers[index].register_forward_hook(hook))
    begin=time.perf_counter()
    with torch.inference_mode():
        initial=model.tfmr(inputs_embeds=torch.from_numpy(inp),use_cache=bool(a.cpu_tokens),return_dict=True);y=initial.last_hidden_state[:,-1:]
        np.save(out/'cpu-norm.npy',y.numpy());np.save(out/'cpu-speech-logits.npy',model.speech_head(y).numpy());np.save(out/'cpu-text-logits.npy',model.text_head(y).numpy())
    for hook in hooks:hook.remove()
    if a.cpu_tokens:
        rng=np.random.default_rng(42);history=[6561];past=initial.past_key_values
        with torch.inference_mode():
            def project(value):
                z=model.speech_head(value).numpy().reshape(inp.shape[0],8194)
                return z[0]+a.cfg_weight*(z[0]-z[1]) if a.cfg_weight else z[0]
            logits=project(y);generated=[]
            for step in range(a.cpu_tokens):
                scores=logits.astype(np.float64);seen=np.unique(history);scores[seen]=np.where(scores[seen]<0,scores[seen]*2,scores[seen]/2);scores/=0.8
                prob=np.exp(scores-scores.max());prob[prob<0.05*prob.max()]=0;prob/=prob.sum();token=int(rng.choice(len(prob),p=prob));generated.append(token);history.append(token)
                if token==6562:break
                token_embed=decoded['speech_emb.weight'][token]+decoded['speech_pos_emb.emb.weight'][step+1]
                token_embed=torch.from_numpy(token_embed).bfloat16().float().reshape(1,1,1024).expand(inp.shape[0],-1,-1)
                output=model.tfmr(inputs_embeds=token_embed,past_key_values=past,use_cache=True,return_dict=True);past=output.past_key_values;logits=project(output.last_hidden_state)
            rec['cpuGeneration']=dict(tokens=generated,terminatedWithEos=bool(generated and generated[-1]==6562),seed=42,limit=a.cpu_tokens)
            print('CPU generated',len(generated),'EOS',rec['cpuGeneration']['terminatedWithEos'],flush=True)
    rec['cpuReferenceSeconds']=time.perf_counter()-begin;rec['preparedFiles']=[dict(path=f.name,sha256=sha(f)) for f in sorted(out.glob('*.npy'))];rec['completed']=True;save();print(json.dumps(rec,ensure_ascii=False),flush=True)
if __name__=='__main__':main()

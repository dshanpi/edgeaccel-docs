"""Validate the fixed companion files without allocating an AXCL device."""
from pathlib import Path
import argparse, hashlib, json

HERE = Path(__file__).resolve().parent

def read_manifest():
    return json.loads((HERE / 'models.json').read_text('utf-8'))

def verify(root, roles=None):
    manifest = read_manifest()
    rows = []
    for repo in manifest['repositories']:
        if roles and repo['role'] not in roles:
            continue
        base = (Path(root) / repo['role']).resolve()
        for item in repo['files']:
            path = (base / item['path']).resolve()
            if not path.is_relative_to(base) or not path.is_file():
                raise ValueError(f'Missing or invalid model file: {path}')
            with path.open('rb') as stream:
                actual = hashlib.file_digest(stream, 'sha256').hexdigest()
            if path.stat().st_size != item['size'] or actual != item['sha256']:
                raise ValueError(f'Model checksum differs: {path}')
            rows.append(dict(role=repo['role'], path=item['path'], sha256=actual))
    if not rows:
        raise ValueError('No model files selected')
    return rows

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--models-dir', type=Path, required=True)
    args = parser.parse_args()
    rows = verify(args.models_dir)
    print(json.dumps(dict(verifiedFiles=len(rows), modelRoot=str(args.models_dir.resolve()))))

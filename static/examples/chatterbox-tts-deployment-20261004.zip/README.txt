Chatterbox T3 + AXERA one-step S3Gen/HiFT deployment
PC: Python 3.12, PyTorch 2.6.0 CPU, requirements-pc.txt. Run download_models.py and prepare_chatterbox_t3.py with cfg-weight 0.5.
RK3576: Python 3.12, PyAXEngine AXCL, NumPy 1.26.4, Torch 2.5.1, Transformers 4.51.3.
Run chatterbox_t3_card.py then chatterbox_audio_card.py, through readonly SSH model mount.
T3 must produce EOS. Clone decoder accepts at most 99 generated acoustic tokens; no truncation.
Follow the matching deployment guide for commands and fixed environment.
Original preprocessing modules copied byte-for-byte from chatterbox-tts 0.1.7 wheel; upstream license included.

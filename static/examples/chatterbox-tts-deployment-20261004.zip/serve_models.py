"""Read-only loopback file server for an SSH-forwarded rclone mount."""
from pathlib import Path
import argparse, html, http.server, json, re, threading, time, urllib.parse
from verify_models import read_manifest, verify

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--models-dir', type=Path, required=True)
    parser.add_argument('--port', type=int, default=18865)
    parser.add_argument('--stop-file', type=Path)
    args = parser.parse_args()
    if args.stop_file and args.stop_file.exists():
        raise ValueError('Remove the previous stop marker before starting a new session')
    rows = verify(args.models_dir)
    files = {}; directories = {'': set()}
    for repo in read_manifest()['repositories']:
        for item in repo['files']:
            name = repo['role'] + '/' + item['path']
            files[name] = ((args.models_dir / name).resolve(), item)
            parts = name.split('/')
            for i, part in enumerate(parts):
                directories.setdefault('/'.join(parts[:i]), set()).add(part + ('/' if i < len(parts)-1 else ''))

    class Handler(http.server.BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'
        def log_message(self, *args):
            pass
        def handle(self):
            try:
                super().handle()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
        def do_HEAD(self):
            self.send_file(False)
        def do_GET(self):
            self.send_file(True)
        def send_file(self, body):
            relative = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path).lstrip('/')
            if relative.endswith('/') or not relative:
                key = relative.rstrip('/')
                if key not in directories:
                    self.send_error(404); return
                raw = ('<html><body>' + ''.join('<a href="' + urllib.parse.quote(n) + '">' + html.escape(n) + '</a><br>' for n in sorted(directories[key])) + '</body></html>').encode()
                self.send_response(200); self.send_header('Content-Length', str(len(raw))); self.send_header('Content-Type', 'text/html; charset=utf-8'); self.end_headers()
                if body: self.wfile.write(raw)
                return
            if relative not in files:
                self.send_error(404); return
            path, item = files[relative]; size = item['size']; first, last = 0, size-1
            requested = self.headers.get('Range')
            if requested:
                match = re.fullmatch(r'bytes=(\d+)-(\d*)', requested)
                if not match:
                    self.send_error(416); return
                first = int(match[1]); last = min(size-1, int(match[2])) if match[2] else size-1
                if first > last or first >= size:
                    self.send_error(416); return
            self.send_response(206 if requested else 200)
            for k, val in [('Content-Type', 'application/octet-stream'), ('Content-Length', str(last-first+1)), ('Accept-Ranges', 'bytes'), ('ETag', '"'+item['sha256']+'"')]:
                self.send_header(k, val)
            if requested: self.send_header('Content-Range', f'bytes {first}-{last}/{size}')
            self.end_headers()
            if body:
                with path.open('rb') as stream:
                    stream.seek(first); remaining = last-first+1
                    while remaining:
                        block = stream.read(min(1024**2, remaining))
                        if not block: raise OSError('Model file became shorter while serving')
                        self.wfile.write(block); remaining -= len(block)
    server = http.server.ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(json.dumps(dict(ready=True, verifiedFiles=len(rows), url=f'http://127.0.0.1:{args.port}/')), flush=True)
    try:
        while not (args.stop_file and args.stop_file.exists()): time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown(); server.server_close()

if __name__ == '__main__':
    main()

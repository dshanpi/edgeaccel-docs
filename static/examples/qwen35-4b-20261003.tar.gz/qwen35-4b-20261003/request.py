"""Request text, one image, or a local video/frame directory from AXCL axllm."""
import argparse,json,urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--base-url',default='http://127.0.0.1:8000');p.add_argument('--prompt',required=True);media=p.add_mutually_exclusive_group();media.add_argument('--image',type=Path);media.add_argument('--video',type=Path);p.add_argument('--max-tokens',type=int,default=128);p.add_argument('--raw-output',type=Path);p.add_argument('--request-output',type=Path);a=p.parse_args()
assert 1<=a.max_tokens<=1024,'max-tokens must be1..1024';base=a.base_url.rstrip('/');http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
with http.open(base+'/v1/models',timeout=15) as r:models=json.load(r)
expected='AXERA-TECH/Qwen3.5-4B-AX650-GPTQ-Int4-C512-P30k-CTX32k';assert expected in [x['id'] for x in models['data']],'Unexpected model service'
content=[dict(type='text',text=a.prompt)]
for key in ['image','video']:
 path=getattr(a,key)
 if path:
  path=path.expanduser().resolve();assert path.exists(),path
  content.append(dict(type=key+'_url',**{key+'_url':dict(url=str(path))}))
body=dict(model=expected,messages=[dict(role='system',content='you are a helpful assistant.'),dict(role='user',content=content)],max_tokens=a.max_tokens,temperature=0.0,stream=False,enable_thinking=False)
if a.request_output:a.request_output.write_text(json.dumps(body,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
req=urllib.request.Request(base+'/v1/chat/completions',data=json.dumps(body,ensure_ascii=False).encode(),headers={'Content-Type':'application/json'})
with http.open(req,timeout=310) as r:answer=json.load(r)
if a.raw_output:a.raw_output.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(answer['choices'][0]['message']['content'])

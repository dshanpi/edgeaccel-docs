from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).expanduser().resolve();m=json.loads(Path(__file__).with_name('download-manifest.json').read_text(encoding='utf-8'))
for f in m['files']:
 p=(root/f['path']).resolve();assert p.is_relative_to(root) and p.stat().st_size==f['size'],f['path']
 with p.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==f['verifiedHashes']['sha256'],f['path']
print('Verified 40 model files')

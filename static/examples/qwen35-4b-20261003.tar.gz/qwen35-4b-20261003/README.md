# Qwen3.5-4B C512/P30K/CTX32K AXCL ARM64 runtime

The axllm executable is the unchanged official AXERA-TECH ax-llm AXCL ARM64 release asset. See upstream.json for its digest and identity, and AXLLM-LICENSE for the upstream license. It reports source b704e2f3dc4e and tokenizer a08af3838d76. Install AXCL 3.16 on the Linux ARM64 host first and check `ldd axllm`; use the AXCL runtime for the M.2 card.

Download the separate model repository AXERA-TECH/Qwen3.5-4B-AX650-GPTQ-Int4-C512-P30k-CTX32k at revision 4222f23a3459751d20239a51621df62538cfd409. Run `python3 verify_models.py MODEL_DIR` with Python 3.11 or later to verify its 40 files. Keep the original model configuration and memory guard enabled. Allow at least 16 GiB of free disk space for the 11.2 GiB model package.

Start `AXLLM_DEVICES=0 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 ./axllm serve MODEL_DIR --port 8000`. In another host terminal run `python3 request.py --prompt 'What is 2 + 3? Reply with only the number.'`. The client supports `--image FILE` and `--video DIRECTORY`, and expects paths accessible on the service host. It preserves complete JSON responses when `--raw-output FILE` is set.

The companion images and ordered video frames retain their original bytes; sources and SHA256 digests are listed in fixtures-manifest.json. The configured 1 fps interpretation is not a measurement of source capture timing. The documented scope is short requests on one 16GB card; 32K context, an actual 8GB card and sustained load require separate validation.

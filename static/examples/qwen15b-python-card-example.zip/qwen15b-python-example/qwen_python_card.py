"""Execute the reviewed upstream Python adapter with explicit AXCL and raw evidence."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time

PROMPTS = [
    'What is 2 + 3? Reply with only the number.',
    '请用一句中文说明 PCIe 的用途。',
    'Return only a JSON object with apple equal to 3 and pear equal to 2.',
]
MID = 'Qwen2.5-1.5B-Instruct-python'
REV = 'aa999d91e7789a80a00bb910cfed4ca8de2b38a2'
p = argparse.ArgumentParser()
p.add_argument('--model-dir', type=Path, required=True)
p.add_argument('--candidate', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--single', type=int, choices=[1, 2, 3])
p.add_argument('--question', help='Run one question instead of the three demonstration inputs')
p.add_argument('--manifest', type=Path, help='Fixed-version download manifest; defaults to the model directory manifest')
a = p.parse_args()
root, out, candidate = a.model_dir.resolve(), a.output.resolve(), a.candidate.resolve()
manifest_path = a.manifest.resolve() if a.manifest else root/'.validation-download.json'
manifest = json.loads(manifest_path.read_text())
assert manifest['complete'] and manifest['revision'] == REV and len(manifest['files']) == 43
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == 'e7541c7ea630a032d49bdc39a2688f9a252fc6f43d64147fb65e7cd5fab4eb02'
if a.question is not None:
    assert a.question.strip(), 'Question must not be empty'
    PROMPTS = [a.question]

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

if a.single is None:
    out.mkdir(parents=True, exist_ok=False)
    record = {'kind': 'text', 'modelId': MID, 'revision': REV,
              'provider': 'AXCLRTExecutionProvider', 'completed': False, 'samples': [],
              'candidateSha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
              'runtimeEnvironment': {k: os.environ[k] for k in ['OMP_NUM_THREADS', 'OMP_THREAD_LIMIT'] if k in os.environ}}
    write(out/'result.json', record)
    for i, prompt in enumerate(PROMPTS, 1):
        cmd = [sys.executable, str(Path(__file__).resolve()), '--model-dir', str(root),
               '--candidate', str(candidate), '--output', str(out), '--single', str(i),
               '--manifest', str(manifest_path)]
        if a.question is not None:
            cmd += ['--question', a.question]
        start = time.monotonic()
        with (out/f'cli-{i}.log').open('w', encoding='utf-8') as log:
            try:
                process = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, timeout=600)
                code = process.returncode
            except subprocess.TimeoutExpired:
                code = 124
        result_path = out/f'sample-{i}.json'
        detail = json.loads(result_path.read_text()) if result_path.exists() else {}
        entry = {'input': prompt, 'output': detail.get('output', ''), 'exitCode': code,
                 'processSeconds': time.monotonic()-start, 'detail': result_path.name,
                 'eosReached': detail.get('eosReached', False),
                 'completed': detail.get('completed', False)}
        record['samples'].append(entry)
        write(out/'result.json', record)
        print(json.dumps(entry, ensure_ascii=False), flush=True)
        if code != 0 or not entry['completed'] or not entry['eosReached']:
            raise SystemExit(1)
    record['completed'] = True
    write(out/'result.json', record)
    raise SystemExit(0)

import axengine
import numpy as np
assert 'AXCLRTExecutionProvider' in axengine.get_available_providers()
original_session = axengine.InferenceSession
sample = {'input': PROMPTS[a.single-1], 'modelId': MID, 'revision': REV,
          'completed': False, 'provider': 'AXCLRTExecutionProvider', 'sessions': [],
          'packages': {k: importlib.metadata.version(k) for k in
                       ['torch', 'torchvision', 'axengine', 'numpy', 'ml_dtypes', 'transformers', 'tokenizers']}}
sample_path = out/f'sample-{a.single}.json'
post_tokens = []

class MeasuredSession:
    def __init__(self, model, **kwargs):
        kwargs['providers'] = ['AXCLRTExecutionProvider']
        start = time.monotonic()
        self.session = original_session(model, **kwargs)
        actual_provider = self.session.get_providers()
        assert actual_provider == 'AXCLRTExecutionProvider', actual_provider
        self.row = {'model': str(Path(model).relative_to(root)),
                    'providerRequested': kwargs['providers'], 'loadSeconds': time.monotonic()-start,
                    'providerActual': actual_provider,
                    'inputs': [{'name': v.name, 'shape': list(v.shape), 'dtype': str(v.dtype)} for v in self.session.get_inputs()],
                    'shapeGroupCalls': {}, 'runSeconds': 0, 'allFinite': True}
        sample['sessions'].append(self.row)
        write(sample_path, sample)

    def __getattr__(self, name):
        return getattr(self.session, name)

    def run(self, names, feeds, **kwargs):
        start = time.monotonic()
        values = self.session.run(names, feeds, **kwargs)
        self.row['runSeconds'] += time.monotonic()-start
        group = str(kwargs.get('shape_group', 0))
        self.row['shapeGroupCalls'][group] = self.row['shapeGroupCalls'].get(group, 0)+1
        if not all(np.isfinite(v.astype(np.float32)).all() for v in values):
            self.row['allFinite'] = False
            write(sample_path, sample)
            raise ValueError('Non-finite inference output')
        if self.row['model'].endswith('/qwen2_post.axmodel'):
            post_tokens.append(int(np.argmax(values[0].astype(np.float32).flatten())))
        return values

axengine.InferenceSession = MeasuredSession
write(sample_path, sample)
sys.argv = [str(candidate), '--hf_model', str(root/'Qwen2.5-1.5B-Instruct-GPTQ-Int8'),
            '--axmodel_path', str(root/'Qwen2.5-1.5B-Instruct-GPTQ-Int8_axmodel'), '-q', sample['input']]
try:
    os.chdir(root)
    start = time.monotonic()
    state = runpy.run_path(str(candidate), run_name='__main__')
    sample['scriptSeconds'] = time.monotonic()-start
    input_ids = [int(x) for x in state['token_ids'][:state['token_len']]]
    output_ids = [int(x) for x in state['token_ids'][state['token_len']:]]
    assert state['prompt'] == sample['input'] and output_ids == post_tokens
    assert len(sample['sessions']) == 29
    sample.update(inputTokenIds=input_ids, outputTokenIds=output_ids,
                  messages=state['messages'], formattedInput=state['text'],
                  eosTokenId=state['tokenizer'].eos_token_id,
                  output=state['tokenizer'].decode(output_ids, skip_special_tokens=True),
                  eosReached=bool(output_ids and output_ids[-1] == state['tokenizer'].eos_token_id),
                  contextBoundaryReached=len(input_ids)+len(output_ids) >= state['lastN'],
                  greedyOutputMatchesPostArgmax=True, completed=True)
    print('\nCOMPLETE_TOKEN_DECODE:', sample['output'], flush=True)
except BaseException as exc:
    sample['error'] = repr(exc)
    raise
finally:
    write(sample_path, sample)

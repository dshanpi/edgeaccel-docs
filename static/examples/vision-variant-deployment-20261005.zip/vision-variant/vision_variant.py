"""Run fixed official vision variants on an AXCL M.2 card."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
def main():
 root=Path(__file__).resolve().parent
 manifest=json.loads((root/'bundle-manifest.json').read_text('utf-8'))
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--case',choices=manifest['cases'],required=True)
 p.add_argument('--models-root',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True)
 a=p.parse_args()
 for name,digest in manifest['files'].items():
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 if a.output.exists():p.error('Choose a new output directory.')
 boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
 return subprocess.run([sys.executable,str(root/'_runtime.py'),'--plan',str(root/'plan.json'),'--models-root',str(a.models_root.resolve()),'--case',a.case,'--output',str(a.output.resolve()),'--expected-boot',boot],check=False).returncode
if __name__=='__main__':sys.exit(main())

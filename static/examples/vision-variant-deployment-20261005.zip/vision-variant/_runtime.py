"""Run pinned original CV scripts with AXCL and capture unmodified tensors."""
import argparse,datetime,hashlib,json,os,platform,runpy,sys,time
from pathlib import Path

def sha(p):
    with p.open('rb') as h:return hashlib.file_digest(h,'sha256').hexdigest()

def main():
    ap=argparse.ArgumentParser()
    for key in ['plan','models-root','case','output','expected-boot']:ap.add_argument('--'+key,required=True)
    a=ap.parse_args();assert platform.machine() in ['aarch64','arm64']
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==a.expected_boot
    case=next(c for c in json.loads(Path(a.plan).read_text())['cases'] if c['case']==a.case)
    base=(Path(a.models_root)/case['modelId']).resolve();out=Path(a.output).resolve()
    assert not out.is_relative_to(base);out.mkdir(parents=True,exist_ok=False)
    for f in case['files']:assert sha(base/f['path'])==f['sha256']
    import cv2,numpy as np,axengine
    original_session=axengine.InferenceSession;original_write=cv2.imwrite
    record=dict(case=case,provider='AXCLRTExecutionProvider',bootId=a.expected_boot,calls=[],images=[],metadata=[],accepted=False,adapterSha256=sha(Path(__file__)),startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
    def save():(out/'result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    def info(x):return dict(name=x.name,shape=list(x.shape),dtype=str(np.dtype(x.dtype)))
    class Session:
        def __init__(self,path,*args,**kwargs):
            assert Path(path).resolve()==(base/case['weight']).resolve()
            self.real=original_session(str(base/case['weight']),providers=['AXCLRTExecutionProvider'])
            record['metadata'].append(dict(inputs=[info(x) for x in self.real.get_inputs()],outputs=[info(x) for x in self.real.get_outputs()]))
            save()
        def __getattr__(self,name):return getattr(self.real,name)
        def run(self,names,feed,*args,**kwargs):
            metas=self.real.get_inputs();assert set(feed)=={m.name for m in metas}
            for m in metas:
                value=feed[m.name];assert list(value.shape)==list(m.shape) and value.dtype==np.dtype(m.dtype)
                assert np.isfinite(value).all()
            n=len(record['calls']);ip=out/f'input-{n}.npz';np.savez(ip,**feed)
            item=dict(input=ip.name,inputSha256=sha(ip));record['calls'].append(item);save()
            started=time.perf_counter();values=self.real.run(names,feed,*args,**kwargs);item['wallMs']=(time.perf_counter()-started)*1000
            assert all(np.isfinite(v).all() for v in values)
            op=out/f'raw-{n}.npz';np.savez(op,**{f'output{i}':v for i,v in enumerate(values)})
            item.update(output=op.name,outputSha256=sha(op),returned=True);save();return values
    def write(name,value,*args):
        dest=out/Path(name).name
        assert original_write(str(dest),value,*args)
        record['images'].append(dict(path=dest.name,sha256=sha(dest),shape=list(value.shape)));save();return True
    previous=Path.cwd();argv=sys.argv;axengine.InferenceSession=Session;cv2.imwrite=write
    try:
        os.chdir(base);save()
        sys.argv=[case['script']]+[v.replace('{output}',str(out)) for v in case['argv']]
        runpy.run_path(str(base/case['script']),run_name='__main__')
        assert len(record['calls'])==case['expectedCalls'] and all(c.get('returned') for c in record['calls'])
        assert record['images']
        for f in case['files']:assert sha(base/f['path'])==f['sha256']
        record.update(status='completed-awaiting-independent-review',sourceHashesUnchanged=True)
    except BaseException as exc:record.update(status='failed',error=repr(exc));raise
    finally:
        os.chdir(previous);sys.argv=argv;axengine.InferenceSession=original_session;cv2.imwrite=original_write
        record['bootIdAfter']=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        record['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()

if __name__=='__main__':main()

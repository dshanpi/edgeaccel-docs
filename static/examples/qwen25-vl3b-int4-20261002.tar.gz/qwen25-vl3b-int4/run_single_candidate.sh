#!/usr/bin/env bash
# Private candidate: not yet run on the accelerator. One input per fresh process.
set -euo pipefail
if [ "$#" -ne 3 ]; then echo "Usage: $0 image|video INPUT_PATH PROMPT" >&2; exit 2; fi
case "$1" in image) video=0 ;; video) video=1 ;; *) exit 2 ;; esac
input=$(realpath -- "$2")
[[ -r "$input" ]]
fps=${EDGEACCEL_VIDEO_FPS:-1}
[[ "$fps" =~ ^[1-9][0-9]*$ ]]
if [[ "$video" == 1 ]]; then [[ -d "$input" ]]; fi
[[ "$input" != *$'\n'* && "$3" != *$'\n'* && -n "$3" && "$3" != q ]]
[[ $(uname -m) == aarch64 ]]
[[ $(cat /proc/sys/kernel/random/boot_id) != feac3838-e1c6-42d2-a11a-005f5a786039 ]]
binary=${EDGEACCEL_QWEN_BINARY:?Set path to the reviewed AXCL companion binary}
model=${EDGEACCEL_QWEN_WEIGHTS:?Set path to Qwen2.5-VL-3B-Instruct-AX650-c128_p1536-ctx2047-int4}
tokenizer=${EDGEACCEL_TOKENIZER_URL:?Start the matching image or video candidate service and set its URL}
dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ $(sha256sum -- "$binary" | cut -d ' ' -f1) == 255430072183943d0356a3979bd968527bc257d5807ec2ac21838a99a06fa9e8 ]]
for ((i=0;i<36;i++)); do [[ -r "$model/qwen2_5_vl_p128_l${i}_together.axmodel" ]]; done
for file in Qwen2.5-VL-3B-Instruct_vision_image_392.axmodel qwen2_5_vl_post.axmodel model.embed_tokens.weight.bfloat16.bin; do [[ -r "$model/$file" ]]; done
# Complete manifest/health checks and image decoding must precede this launcher.
printf '%s\n%s\nq\n' "$3" "$input" | timeout --signal=INT --kill-after=20 900 "$binary" \
  --devices 0 \
  --template_filename_axmodel "$model/qwen2_5_vl_p128_l%d_together.axmodel" \
  --axmodel_num 36 \
  --filename_image_encoder_axmodedl "$model/Qwen2.5-VL-3B-Instruct_vision_image_392.axmodel" \
  --use_mmap_load_embed 0 \
  --filename_tokenizer_model "$tokenizer" \
  --filename_post_axmodel "$model/qwen2_5_vl_post.axmodel" \
  --filename_tokens_embed "$model/model.embed_tokens.weight.bfloat16.bin" \
  --tokens_embed_num 151936 --tokens_embed_size 2048 \
  --live_print 0 --video "$video" \
  --img_width 392 --img_height 392 \
  --vision_start_token_id 151652 \
  --temporal_patch_size 2 --spatial_merge_size 2 --patch_size 14 \
  --fps "$fps" --tokens_per_second 2 \
  --post_config_path "$dir/post-greedy.json"

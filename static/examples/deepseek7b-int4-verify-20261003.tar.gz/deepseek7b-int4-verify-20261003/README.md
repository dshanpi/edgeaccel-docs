# DeepSeek 7B Int4 文件校验

此包仅包含校验脚本与固定模型清单，不包含模型权重或推理程序。

使用 Python 3.9 或更高版本执行：

```bash
python3 verify_models.py /absolute/path/to/model
```

全部 43 个文件大小与 SHA256 一致时，输出 `Verified 43 model files` 并返回 0。
任何文件缺失或不匹配均返回非零退出码。重新下载对应文件，校验通过后再启动模型。
完整部署步骤见配套网站的 DeepSeek-R1-Distill-Qwen-7B-GPTQ-Int4 部署指南。

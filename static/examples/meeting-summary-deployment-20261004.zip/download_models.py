"""Download the pinned official files and write the verified runtime manifest."""
from pathlib import Path
import argparse,hashlib,json,shutil
HERE=Path(__file__).resolve().parent
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--models-dir',type=Path,required=True);p.add_argument('--verify-only',action='store_true');a=p.parse_args()
    m=json.loads((HERE/'download-manifest.json').read_text());root=a.models_dir/m['modelId']
    if not a.verify_only:
        from huggingface_hub import hf_hub_download
        root.mkdir(parents=True,exist_ok=True)
    for item in m['files']:
        target=root/item['path'];expected=item['verifiedHashes']['sha256']
        if not target.is_file() or sha(target)!=expected:
            if a.verify_only:raise ValueError('Missing or changed file: '+item['path'])
            hf_hub_download(repo_id=m['repo'],filename=item['path'],revision=m['revision'],local_dir=root,force_download=True)
        if target.stat().st_size!=item['size'] or sha(target)!=expected:raise ValueError('Checksum differs: '+item['path'])
        print('Verified',item['path'],flush=True)
    if not a.verify_only:shutil.copy2(HERE/'download-manifest.json',root/'.validation-download.json')
    print('Verified',len(m['files']),'fixed model and support files')
if __name__=='__main__':main()

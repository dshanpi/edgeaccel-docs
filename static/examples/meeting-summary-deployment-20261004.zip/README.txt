3D-Speaker-Meeting-Summary
Fixed revision: b55d044e8eb419c779dc15c4b3e486dfe531f67e
Requires Python 3.12, a PC model directory, SSH reverse forwarding, and rclone readonly mount on the RK3576.
Run download_models.py on the PC, serve_models.py on the PC, and meeting_summary_card.py on the RK3576.
Follow the matching customer deployment guide for environment setup and exact commands.
Do not run the AXCL program on the PC.

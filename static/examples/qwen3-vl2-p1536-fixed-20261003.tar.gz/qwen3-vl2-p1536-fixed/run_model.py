"""Run Qwen3-VL-2B Int4 P1536 on an ARM64 AXCL host with the validated configuration."""
from pathlib import Path
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser();p.add_argument('mode',choices=['image','video']);p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--prompt',required=True);p.add_argument('--encoder',choices=['384','640','u8'],default='384');p.add_argument('--dry-run',action='store_true');a=p.parse_args();resolution=640 if a.encoder=='640' else 384;vision='Qwen3-VL-2B-Instruct_vision'+({'384':'','640':'_640x640','u8':'_u8'}[a.encoder])+'.axmodel'
root=Path(__file__).resolve().parent;model=a.model_dir.resolve();media=a.input.resolve();weights=model/'Qwen3-VL-2B-Instruct-AX650-c128_p1536_ctx2047-int4'
assert a.prompt.strip() and '\n' not in a.prompt and '\r' not in a.prompt and '\n' not in str(media)
for name,digest in {'main_axcl_aarch64': 'edce8d010fee8050cef9e8f494696346055d692e55feb619573b2bc75cd7db93', 'qwen3_tokenizer.txt': '46fafa42f69d10f67677adffd3ca6285e0c97b7deddfebaa98ceeac3557f04a3', 'post-greedy.json': '1ec79ac41edf027ec2f66be740bb7f4c2c1188edd1ddd8e16922068dba61938f'}.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
if a.mode=='image':assert media.is_file()
else:
 if not media.is_dir():p.error('Video input must be a JPEG directory')
 frames=sorted(media.iterdir())
 if len(frames) not in [2,4,6,8] or not all(x.is_file() and x.suffix.lower()=='.jpg' for x in frames):p.error('Use 2, 4, 6 or 8 ordered JPEG frames at 1 fps')
 if a.encoder=='640' and len(frames)>6:p.error('640 encoder supports at most six frames: eight frames need at least 1600 visual tokens, exceeding the 1536 input limit')
cmd=['./main_axcl_aarch64','--template_filename_axmodel',str(weights/'qwen3_vl_text_p128_l%d_together.axmodel'),'--axmodel_num','28','--filename_image_encoder_axmodedl',str(weights/vision),'--use_mmap_load_embed','0','--filename_tokenizer_model',str(root/'qwen3_tokenizer.txt'),'--filename_post_axmodel',str(weights/'qwen3_vl_text_post.axmodel'),'--filename_tokens_embed',str(weights/'model.embed_tokens.weight.bfloat16.bin'),'--tokens_embed_num','151936','--tokens_embed_size','2048','--live_print','0','--video','1' if a.mode=='video' else '0','--img_width',str(resolution),'--img_height',str(resolution),'--vision_start_token_id','151652','--post_config_path',str(root/'post-greedy.json'),'--devices','0','--temporal_patch_size','2','--spatial_merge_size','2','--patch_size','16','--fps','1','--tokens_per_second','2']
stdin=a.prompt+'\n'+str(media)+'\nq\n'
if a.dry_run:print(json.dumps(dict(command=cmd,stdin=stdin),ensure_ascii=False));raise SystemExit(0)
raise SystemExit(subprocess.run(cmd,input=stdin,text=True,encoding='utf-8',cwd=root,timeout=600).returncode)

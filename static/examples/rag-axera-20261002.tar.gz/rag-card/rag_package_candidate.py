"""Validate the fixed RAG package before importing or loading AXCL models."""
import hashlib
import json
from pathlib import Path, PurePosixPath


def verify_package(package_root, manifest_path, manifest_sha256):
    root = Path(package_root).resolve(strict=True)
    raw = Path(manifest_path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != manifest_sha256:
        raise ValueError('RAG file list checksum mismatch')
    manifest = json.loads(raw)
    if manifest['revision'] != '1ed9a31a4ffb70912a225e0247e4b14158a67a7b':
        raise ValueError('Unexpected RAG revision')
    seen = set()
    total = 0
    for item in manifest['files']:
        relative = PurePosixPath(item['path'])
        if relative.is_absolute() or '..' in relative.parts or str(relative) in seen:
            raise ValueError('Invalid or repeated package path')
        seen.add(str(relative))
        file = root.joinpath(*relative.parts).resolve(strict=True)
        if not file.is_relative_to(root) or not file.is_file():
            raise ValueError('Package path escapes package directory')
        if file.stat().st_size != item['size']:
            raise ValueError(f'Package size mismatch: {relative}')
        digest = hashlib.sha256()
        with file.open('rb') as stream:
            for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                digest.update(block)
        if digest.hexdigest() != item['sha256']:
            raise ValueError(f'Package checksum mismatch: {relative}')
        total += item['size']
    if len(seen) != manifest['fileCount'] or total != manifest['totalBytes']:
        raise ValueError('Package list totals mismatch')
    return {'revision': manifest['revision'], 'verifiedFiles': len(seen), 'verifiedBytes': total}

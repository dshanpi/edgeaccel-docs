"""Private readable-document RAG index. No model is loaded by importing this module."""
from pathlib import Path
import hashlib,io,json,os,re,uuid
import numpy as np

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def load_pages(path):
    path=Path(path);data=path.read_bytes();source_hash=hashlib.sha256(data).hexdigest()
    if path.suffix.lower()=='.pdf':
        from PyPDF2 import PdfReader
        pages=[(i+1,page.extract_text() or '') for i,page in enumerate(PdfReader(io.BytesIO(data)).pages)]
    elif path.suffix.lower()=='.txt':
        try:text=data.decode('utf-8-sig')
        except UnicodeDecodeError:text=data.decode('gb18030')
        pages=[(1,text)]
    else:raise ValueError('Use a PDF or TXT file')
    return [dict(source=path.name,source_sha256=source_hash,page=page,text=text) for page,text in pages]

def split_pages(pages,tokenizer,max_tokens=320,overlap_chars=48):
    if not isinstance(max_tokens,int) or max_tokens<1 or overlap_chars<0:raise ValueError('Invalid chunk limits')
    chunks=[]
    for page in pages:
        text=page['text'];start=0
        if not text.strip():continue
        while start<len(text):
            # Search character boundaries, then verify the actual tokenizer count.
            low=start+1;high=len(text);end=start
            while low<=high:
                middle=(low+high)//2
                if len(tokenizer.encode(text[start:middle],add_special_tokens=False))<=max_tokens:
                    end=middle;low=middle+1
                else:high=middle-1
            if end==start:raise ValueError('One character exceeds the token budget')
            piece=text[start:end];count=len(tokenizer.encode(piece,add_special_tokens=False))
            if not 0<count<=max_tokens:raise ValueError('Chunk token count is invalid')
            chunks.append({k:v for k,v in page.items() if k!='text'}|dict(id=len(chunks),start=start,end=end,text=piece,token_count=count))
            if end==len(text):break
            start=max(start+1,end-min(overlap_chars,(end-start)//2))
    if not chunks:raise ValueError('The document has no extractable text')
    return chunks

def normalize(vectors):
    values=np.asarray(vectors,dtype=np.float32)
    if values.ndim!=2 or not np.isfinite(values).all():raise ValueError('Embedding must be a finite matrix')
    norms=np.linalg.norm(values,axis=1,keepdims=True)
    if np.any(norms<=1e-12):raise ValueError('Embedding has a zero vector')
    return values/norms

class DocumentIndex:
    def __init__(self,directory,embedding_identity):
        self.directory=Path(directory);self.identity=embedding_identity

    def build(self,pages,tokenizer,encode,max_tokens=320,overlap_chars=48):
        chunks=split_pages(pages,tokenizer,max_tokens,overlap_chars)
        vectors=[]
        for chunk in chunks:
            # Each document chunk is encoded independently with no batch padding.
            value=normalize(encode([chunk['text']],is_query=False))
            if value.shape[0]!=1:raise ValueError('Expected one document embedding')
            vectors.append(value[0])
        matrix=np.stack(vectors).astype(np.float32)
        generation=uuid.uuid4().hex;folder=self.directory/generation;folder.mkdir(parents=True,exist_ok=False)
        metadata=dict(schema=1,embedding_identity=self.identity,count=len(chunks),dimension=int(matrix.shape[1]),max_tokens=max_tokens,overlap_chars=overlap_chars,chunks=chunks)
        (folder/'chunks.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        np.save(folder/'vectors.npy',matrix,allow_pickle=False)
        pointer=dict(schema=1,generation=generation,chunks_sha256=digest(folder/'chunks.json'),vectors_sha256=digest(folder/'vectors.npy'))
        temporary=self.directory/('active-'+generation+'.tmp')
        temporary.write_text(json.dumps(pointer,indent=2)+'\n',encoding='utf-8')
        os.replace(temporary,self.directory/'active.json')
        return dict(generation=generation,count=len(chunks),dimension=int(matrix.shape[1]))

    def load(self):
        pointer=json.loads((self.directory/'active.json').read_text('utf-8'))
        if pointer.get('schema')!=1 or not re.fullmatch('[0-9a-f]{32}',pointer.get('generation','')):raise ValueError('Invalid index pointer')
        folder=self.directory/pointer['generation']
        if digest(folder/'chunks.json')!=pointer['chunks_sha256'] or digest(folder/'vectors.npy')!=pointer['vectors_sha256']:raise ValueError('Index checksum mismatch')
        metadata=json.loads((folder/'chunks.json').read_text('utf-8'))
        if metadata['schema']!=1 or metadata['embedding_identity']!=self.identity:raise ValueError('Index belongs to a different embedding model')
        matrix=np.load(folder/'vectors.npy',mmap_mode='r',allow_pickle=False)
        if matrix.dtype!=np.float32 or matrix.shape!=(metadata['count'],metadata['dimension']) or len(metadata['chunks'])!=metadata['count'] or metadata['count']<1:raise ValueError('Index shape mismatch')
        if not np.isfinite(matrix).all():raise ValueError('Non-finite index')
        return metadata,matrix

    def search(self,query,encode,k=3):
        if not query.strip():raise ValueError('Query must not be empty')
        if isinstance(k,bool) or not isinstance(k,int) or k<1:raise ValueError('k must be a positive integer')
        metadata,matrix=self.load();vector=normalize(encode([query],is_query=True))
        if vector.shape!=(1,matrix.shape[1]):raise ValueError('Query embedding dimension mismatch')
        scores=matrix@vector[0];order=np.argsort(-scores,kind='stable')[:min(k,len(scores))]
        return [metadata['chunks'][int(i)]|dict(score=float(scores[i])) for i in order]

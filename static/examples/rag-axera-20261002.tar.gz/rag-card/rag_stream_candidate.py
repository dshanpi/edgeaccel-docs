"""Private SSE candidate for the fixed RAG.axera InferManager; not an inference result."""
import json

def stream_tokens(tokenizer, manager, embeddings, prompt_ids, prefill_data, max_new_tokens):
    if isinstance(max_new_tokens, bool) or not isinstance(max_new_tokens, int) or max_new_tokens < 1:
        raise ValueError('max_new_tokens must be a positive integer')
    if not prompt_ids:
        raise ValueError('prompt_ids must not be empty')
    ids=manager.prefill(tokenizer,list(prompt_ids),prefill_data,slice_len=128)
    if len(ids)!=len(prompt_ids)+1:
        raise RuntimeError('prefill must append exactly one generated token')
    generated=[];emitted='';current=int(ids[-1]);reason='length'
    for index in range(max_new_tokens):
        if current==tokenizer.eos_token_id:
            reason='eos';break
        generated.append(current)
        text=tokenizer.decode(generated,skip_special_tokens=True,clean_up_tokenization_spaces=False)
        if not text.endswith('\ufffd'):
            if not text.startswith(emitted):raise RuntimeError('decode changed an already emitted prefix')
            chunk=text[len(emitted):]
            if chunk:yield 'data: '+json.dumps({'token':chunk},ensure_ascii=False)+'\n\n'
            emitted=text
        if index+1==max_new_tokens:break
        if len(ids)-1>=manager.max_seq_len:
            reason='context';break
        ids,current=manager.decode_next_token(tokenizer,ids,embeddings,slice_len=128,step_idx=len(ids)-1)
        if current is None:raise RuntimeError('decode returned no token')
        current=int(current)
    text=tokenizer.decode(generated,skip_special_tokens=True,clean_up_tokenization_spaces=False)
    if not text.startswith(emitted):raise RuntimeError('final decode changed an already emitted prefix')
    if text[len(emitted):]:yield 'data: '+json.dumps({'token':text[len(emitted):]},ensure_ascii=False)+'\n\n'
    yield 'data: '+json.dumps({'end':True,'finish_reason':reason,'generated_tokens':len(generated)},ensure_ascii=False)+'\n\n'

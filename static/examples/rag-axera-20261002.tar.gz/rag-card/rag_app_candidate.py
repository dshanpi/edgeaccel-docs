"""Private single-process RAG application; actual CLI loads AXCL models only."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import unquote,urlsplit
import argparse,datetime,json,re,threading,time,uuid
from rag_store_candidate import DocumentIndex,load_pages

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()

class RagApplication:
    def __init__(self,embedding,generator,directory,identity,runtime_mode):
        self.embedding=embedding;self.generator=generator;self.directory=Path(directory)
        self.identity=identity;self.runtime_mode=runtime_mode;self.lock=threading.RLock()
        self.index=DocumentIndex(self.directory/'index',identity)
        for name in ['uploads','records']:(self.directory/name).mkdir(parents=True,exist_ok=True)

    def health(self):
        return dict(runtime_mode=self.runtime_mode,model_identity=self.identity,index_exists=(self.directory/'index/active.json').exists())

    def upload(self,filename,data):
        name=filename.replace('\\','/').split('/')[-1]
        if not name or len(name)>240 or '\0' in name or Path(name).suffix.lower() not in ['.pdf','.txt']:raise ValueError('Upload a PDF or TXT document')
        if not data:raise ValueError('Document must not be empty')
        path=self.directory/'uploads'/(uuid.uuid4().hex+Path(name).suffix.lower());path.write_bytes(data)
        started=time.perf_counter()
        with self.lock:
            pages=load_pages(path)
            for page in pages:page['source']=name
            result=self.index.build(pages,self.embedding.tokenizer,self.embedding.encode)
        return result|dict(source=name,source_sha256=pages[0]['source_sha256'],pages=len(pages),seconds=time.perf_counter()-started,runtime_mode=self.runtime_mode)

    def answer(self,question,max_tokens=256,k=3):
        if not isinstance(question,str) or not question.strip():raise ValueError('Question must not be empty')
        if isinstance(max_tokens,bool) or not isinstance(max_tokens,int) or not 1<=max_tokens<=512:raise ValueError('max_tokens must be in [1,512]')
        if isinstance(k,bool) or not isinstance(k,int) or not 1<=k<=8:raise ValueError('k must be in [1,8]')
        request_id=uuid.uuid4().hex
        record=dict(id=request_id,startedAt=now(),runtime_mode=self.runtime_mode,identity=self.identity,question=question,max_tokens=max_tokens,k=k,status='running',text='')
        started=time.perf_counter();generated=None;terminal=None
        with self.lock:
            try:
                if not self.health()['index_exists']:raise ValueError('Upload and index a document first')
                retrieved=self.index.search(question,self.embedding.encode,k=k)
                prepared=self.generator.prepare(question,retrieved)
                used=[p|dict(citation=i+1) for i,p in enumerate(prepared['passages'])]
                record.update(retrieved=retrieved,used=used,prompt_tokens=prepared['prompt_tokens'],dropped_passages=prepared['dropped_passages'])
                yield dict(event='context',request_id=request_id,runtime_mode=self.runtime_mode,passages=used,dropped_passages=prepared['dropped_passages'])
                generated=self.generator.generate(prepared,max_new_tokens=max_tokens)
                for packet in generated:
                    if not packet.startswith('data: '):raise RuntimeError('Invalid internal stream event')
                    event=json.loads(packet.removeprefix('data: ').strip())
                    if 'token' in event:
                        record['text']+=event['token'];yield event
                    if event.get('end'):terminal=event;break
                if terminal is None:raise RuntimeError('Generation stopped without an end event')
                record.update(status='completed',finish_reason=terminal['finish_reason'],generated_tokens=terminal.get('generated_tokens'))
            except GeneratorExit:
                record.update(status='cancelled',error='Client closed the stream');raise
            except Exception as exc:
                record.update(status='failed',error=str(exc));raise
            finally:
                if generated is not None:generated.close()
                record.update(finishedAt=now(),seconds=time.perf_counter()-started)
                (self.directory/'records'/(request_id+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        yield terminal|dict(request_id=request_id,seconds=record['seconds'])

def make_server(app,host='127.0.0.1',port=0):
    class Handler(BaseHTTPRequestHandler):
        protocol_version='HTTP/1.0'
        def log_message(self,*args):pass
        def reply(self,status,data,content_type='application/json; charset=utf-8'):
            if not isinstance(data,bytes):data=json.dumps(data,ensure_ascii=False).encode('utf-8')
            self.send_response(status);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        def do_GET(self):
            path=urlsplit(self.path).path
            if path=='/':return self.reply(200,Path(__file__).with_name('rag_ui_candidate.html').read_bytes(),'text/html; charset=utf-8')
            if path=='/health':return self.reply(200,app.health())
            if re.fullmatch('/records/[0-9a-f]{32}',path):
                file=app.directory/'records'/(path.rsplit('/',1)[-1]+'.json')
                if file.exists():return self.reply(200,file.read_bytes())
            self.reply(404,dict(error='Not found'))
        def do_POST(self):
            stream=None;headers_sent=False
            try:
                length=int(self.headers.get('Content-Length','0'))
                if length<1:raise ValueError('Request body must not be empty')
                if length>20*1024*1024:return self.reply(413,dict(error='Document exceeds 20 MiB'))
                data=self.rfile.read(length)
                if len(data)!=length:raise ValueError('Incomplete request body')
                path=urlsplit(self.path).path
                if path=='/documents':return self.reply(200,app.upload(unquote(self.headers.get('X-Filename','document.txt')),data))
                if path!='/ask':return self.reply(404,dict(error='Not found'))
                body=json.loads(data.decode('utf-8'))
                if not isinstance(body,dict):raise ValueError('Use a JSON object')
                stream=app.answer(body.get('question'),body.get('max_tokens',256),body.get('k',3))
                first=next(stream)  # Validate retrieval/preparation before writing headers.
                if body.get('stream',True):
                    self.send_response(200);self.send_header('Content-Type','text/event-stream; charset=utf-8');self.send_header('Cache-Control','no-cache');self.end_headers();headers_sent=True
                    self.wfile.write(('data: '+json.dumps(first,ensure_ascii=False)+'\n\n').encode());self.wfile.flush()
                    for event in stream:
                        self.wfile.write(('data: '+json.dumps(event,ensure_ascii=False)+'\n\n').encode());self.wfile.flush()
                else:
                    events=[first]+list(stream);ending=events[-1]
                    return self.reply(200,dict(text=''.join(e.get('token','') for e in events),context=first,**ending))
            except (BrokenPipeError,ConnectionResetError):pass
            except Exception as exc:
                if headers_sent:
                    try:self.wfile.write(('data: '+json.dumps(dict(error=str(exc),end=True,finish_reason='error'),ensure_ascii=False)+'\n\n').encode());self.wfile.flush()
                    except (BrokenPipeError,ConnectionResetError):pass
                else:self.reply(400 if isinstance(exc,(ValueError,TypeError,UnicodeError)) else 500,dict(error=str(exc)))
            finally:
                if stream is not None:stream.close()
    return ThreadingHTTPServer((host,port),Handler)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--package-root',type=Path,required=True);parser.add_argument('--data-dir',type=Path,required=True)
    parser.add_argument('--expected-boot-id',required=True);parser.add_argument('--host',default='127.0.0.1');parser.add_argument('--port',type=int,default=7860);parser.add_argument('--device',type=int,default=0);args=parser.parse_args()
    actual=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    if actual!=args.expected_boot_id or actual=='feac3838-e1c6-42d2-a11a-005f5a786039':raise RuntimeError('Run fresh device checks and use the verified boot ID')
    from rag_package_candidate import verify_package
    manifest=verify_package(args.package_root,Path(__file__).with_name('package-files.json'),'6fb78040940bb347ebe511b9079be8020a9f8df30bcb679c31ccf3b8c9fefd7a')
    print(json.dumps(manifest),flush=True)
    from rag_models_candidate import CardEmbedding,CardGenerator
    identity=dict(repo='AXERA-TECH/RAG.axera',revision=manifest['revision'],embedding='Qwen3-Embedding-0.6B',adapter='candidate-20261002')
    app=RagApplication(CardEmbedding.load(args.package_root,args.device),CardGenerator.load(args.package_root,args.device),args.data_dir,identity,'AXCL')
    server=make_server(app,args.host,args.port);print(f'RAG candidate: http://{args.host}:{server.server_port}',flush=True)
    try:server.serve_forever()
    finally:server.server_close()

if __name__=='__main__':main()

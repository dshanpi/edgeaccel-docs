"""Exercise the real official ML HTTP endpoint with repeated bilingual retrieval inputs.

This verifies the ML application path only. Full photo-library UI integration is
tracked separately and must not be inferred from this result.
"""
import argparse,hashlib,json,os,signal,socket,subprocess,sys,time,traceback
from pathlib import Path

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
 def terminate(signum,frame):raise SystemExit(128+signum)
 signal.signal(signal.SIGTERM,terminate)
 p=argparse.ArgumentParser();p.add_argument('--models',type=Path,required=True);p.add_argument('--wheel',type=Path,required=True);p.add_argument('--fixtures',type=Path,required=True);p.add_argument('--service-script',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--port',type=int,default=3603);a=p.parse_args()
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);samples=a.fixtures.resolve();assert 1024<=a.port<=65535
 with socket.socket() as sock:sock.bind(('127.0.0.1',a.port))
 import numpy as np,requests
 source=json.loads((samples/'source-manifest.json').read_text());names=['images/bird.jpg','images/cat.jpg','images/dog-chai.jpeg']
 assert source['repo']=='AXERA-TECH/CLIP-ONNX-AX650-CPP' and source['revision']=='8a330cf1c3f7a881ba222f92d6485e5b6894f8d3'
 for name in names:assert sha(samples/name)==next(f['sha256'] for f in source['files'] if f['path']==name)
 rec=dict(modelId='immich',revision='81c75d735f4087a4359ff152646436da1685af1c',provider='AXCLRTExecutionProvider',completed=False,runnerSha256=sha(__file__),scope='official Immich 2.7.5 ML HTTP text-image retrieval; photo-library UI not tested by this case',webLibraryTested=False,requests=[],retrieval=[],fixtureSource=source,sessions=[])
 def save():(out/'deployment-result.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 save();start=time.perf_counter();proc=None;http=requests.Session();http.trust_env=False;base=f'http://127.0.0.1:{a.port}'
 cmd=[sys.executable,'-u',str(a.service_script),'--models',str(a.models),'--wheel',str(a.wheel),'--output',str(out/'service'),'--port',str(a.port)]
 log=(out/'service.log').open('w')
 try:
  child_env=dict(os.environ,PYTHONFAULTHANDLER='1',PYTHONUNBUFFERED='1')
  proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=child_env)
  ready=time.monotonic()+300
  while time.monotonic()<ready:
   assert proc.poll() is None,'ML service exited before ready'
   try:
    r=http.get(base+'/ping',timeout=2)
    if r.status_code==200 and r.text=='pong':break
   except requests.RequestException:pass
   time.sleep(0.5)
  else:raise TimeoutError('ML service did not become ready')
  rec['startupSeconds']=time.perf_counter()-start;save();raw={}
  pairs=[('ViT-L-14-336__axera','en',['a bird','a cat','a dog']),('ViT-L-14-336-CN__axera','zh',['一只鸟','一只猫','一只狗'])]
  for mid,language,texts in pairs:
   arrays={}
   for mode,inputs in [('visual',names),('textual',texts)]:
    vectors=[]
    for item in inputs:
     repeated=[]
     for repeat in range(2):
      fields={'entries':json.dumps({'clip':{mode:{'modelName':mid,'options':{}}}})};kw={'data':fields};file=None
      if mode=='visual':file=(samples/item).open('rb');kw['files']={'image':(Path(item).name,file,'image/jpeg')}
      else:fields['text']=item
      t=time.perf_counter()
      try:response=http.post(base+'/predict',timeout=180,**kw)
      finally:
       if file:file.close()
      elapsed=time.perf_counter()-t;response.raise_for_status();body=response.json();value=json.loads(body['clip']) if isinstance(body['clip'],str) else body['clip'];vector=np.asarray(value,np.float32)
      assert vector.shape==(768,) and np.isfinite(vector).all() and np.linalg.norm(vector)>0
      repeated.append(vector)
      rec['requests'].append(dict(modelId=mid,mode=mode,input=item,repeat=repeat,status=response.status_code,seconds=elapsed,response=body,vectorSha256=hashlib.sha256(vector.tobytes()).hexdigest()));save()
     assert np.array_equal(repeated[0],repeated[1]),'Repeated identical input produced different vectors'
     vectors.append(repeated)
    arrays[mode]=np.asarray(vectors);raw[language+'_'+mode]=arrays[mode]
   image=arrays['visual'][:,0];text=arrays['textual'][:,0]
   image=image/np.linalg.norm(image,axis=1,keepdims=True);text=text/np.linalg.norm(text,axis=1,keepdims=True)
   scores=image@text.T
   rec['retrieval'].append(dict(modelId=mid,language=language,images=names,texts=texts,cosine=scores.tolist(),imageToTextTop=scores.argmax(axis=1).tolist(),textToImageTop=scores.argmax(axis=0).tolist(),matchingTopAll=bool((scores.argmax(axis=1)==np.arange(3)).all() and (scores.argmax(axis=0)==np.arange(3)).all()),repeatedVectorsIdentical=True,normalization='L2 normalization for cosine; raw HTTP vectors preserved'))
   save()
  np.savez_compressed(out/'embeddings.npz',**raw);rec['rawSha256']=sha(out/'embeddings.npz')
  os.killpg(proc.pid,signal.SIGINT);proc.wait(timeout=300);assert proc.returncode==0
  service=json.loads((out/'service/service-record.json').read_text());assert service['cleanShutdown'] and service['calls']==24 and len(service['sessions'])==4
  assert all(s['calls']==6 and s['allFinite'] for s in service['sessions'])
  rec.update(sessions=service['sessions'],serviceRecordSha256=sha(out/'service/service-record.json'),completed=True)
 except BaseException as exc:rec.update(failure=repr(exc),traceback=traceback.format_exc());raise
 finally:
  if proc and proc.poll() is None:
   os.killpg(proc.pid,signal.SIGINT)
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=2)
  if proc:rec['serviceExitCode']=proc.poll()
  log.close();rec['elapsedSeconds']=time.perf_counter()-start;save()
if __name__=='__main__':main()

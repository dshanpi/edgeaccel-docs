"""Serve the pinned official Immich ML application with offline files and AXCL tracing.

No inference math is replaced. The download callback resolves only fully verified,
fixed local repositories, and the bundled AXSession is explicitly bound to AXCL.
"""
import argparse,hashlib,json,os,sys,threading,time,zipfile
from pathlib import Path

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
 p=argparse.ArgumentParser();p.add_argument('--models',type=Path,required=True);p.add_argument('--wheel',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--port',type=int,default=3003);p.add_argument('--host',default='127.0.0.1');a=p.parse_args()
 root=a.models.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);assert 1024<=a.port<=65535
 wheel_hash=sha(a.wheel);assert wheel_hash=='c204b6d6e6bd1e2dd41277b9bfdc072a062d368d934cb60c274d3d0fd72de18e'
 revisions={'ViT-L-14-336__axera':'d461cbe322991aaec35a359b0defc81356c8db46','ViT-L-14-336-CN__axera':'c99ea50e6f0e3ae9146239035a8217998bb0eda7'}
 record=dict(application='immich',applicationRevision='81c75d735f4087a4359ff152646436da1685af1c',wheelSha256=wheel_hash,runnerSha256=sha(__file__),provider='AXCLRTExecutionProvider',sessions=[],calls=0,filesBefore=[],filesAfter=[],packageFiles=[],models=revisions,cleanShutdown=False)
 lock=threading.RLock()
 def save():
  with lock:
   temp=out/'service-record.json.tmp';temp.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temp.replace(out/'service-record.json')
 save()
 for mid,rev in revisions.items():
  manifest=json.loads((root/mid/'.validation-download.json').read_text());assert manifest['complete'] and manifest['revision']==rev and manifest['modelId']==mid
  for f in manifest['files']:
   file=(root/mid/f['path']).resolve();assert file.is_relative_to(root/mid)
   actual=sha(file);record['filesBefore'].append(dict(modelId=mid,path=f['path'],sha256=actual));save()
   assert actual==f['verifiedHashes']['sha256'],f"File hash differs: {mid}/{f['path']}"
 os.environ.update(HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',MACHINE_LEARNING_CACHE_FOLDER=str(root),MACHINE_LEARNING_MODEL_TTL='0',MACHINE_LEARNING_MODEL_TTL_POLL_S='0',MACHINE_LEARNING_REQUEST_THREADS='0',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
 import numpy as np,uvicorn,immich_ml
 package=Path(immich_ml.__file__).resolve().parent
 with zipfile.ZipFile(a.wheel) as z:
  for info in z.infolist():
   if info.filename.startswith('immich_ml/') and not info.is_dir():
    rel=Path(info.filename).relative_to('immich_ml');expected=hashlib.sha256(z.read(info)).hexdigest();actual=sha(package/rel);assert actual==expected,rel
    record['packageFiles'].append(dict(path=rel.as_posix(),sha256=actual))
 import immich_ml.models.base as base
 from immich_ml.schemas import ModelFormat
 real=base.AXSession
 def offline_download(repo_id,*,cache_dir,local_dir,**kwargs):
  mid=repo_id.removeprefix('AXERA-TECH/');assert repo_id=='AXERA-TECH/'+mid and mid in revisions
  assert Path(local_dir).resolve()==root/mid and Path(cache_dir).resolve()==root/mid
  return str(root/mid)
 base.snapshot_download=offline_download
 # Cache location is the exact pinned repository; preserve official model-path logic.
 original_init=base.InferenceModel.__init__
 def init(instance,model_name,*args,**kwargs):
  assert model_name in revisions,'Only the two pinned CLIP packages are enabled in this validation service'
  kwargs.update(cache_dir=root/model_name,model_format=ModelFormat.AXERA)
  original_init(instance,model_name,*args,**kwargs)
 base.InferenceModel.__init__=init
 def keep_verified_cache(instance):
  record['cacheDeletionPrevented']=instance.model_name;save()
  raise RuntimeError('Failed model load; fixed verified repository preserved for diagnosis')
 base.InferenceModel.clear_cache=keep_verified_cache
 class TracedSession:
  def __init__(self,path,*args,**kwargs):
   file=Path(path).resolve();rel=file.relative_to(root);mid=rel.parts[0];assert mid in revisions
   kwargs['providers']=['AXCLRTExecutionProvider'];start=time.perf_counter();self.real=real(path,*args,**kwargs);assert self.real._provider=='AXCLRTExecutionProvider'
   specs=self.real.get_inputs();assert len(specs)==1
   self.input_name=specs[0].name
   self.row=dict(model='/'.join(rel.parts[1:]),sourceRepo='AXERA-TECH/'+mid,sourceRevision=revisions[mid],sha256=sha(file),provider='AXCLRTExecutionProvider',loadSeconds=time.perf_counter()-start,runMilliseconds=[],allFinite=True,calls=0,inputSpecs=[dict(name=n.name,shape=list(n.shape),dtype=str(n.dtype)) for n in specs],inputMapping={})
   record['sessions'].append(self.row);save()
  def __getattr__(self,key):return getattr(self.real,key)
  def run(self,output_names,input_feed,*args,**kwargs):
   assert len(input_feed)==1
   incoming=next(iter(input_feed));assert incoming in ['image','text']
   self.row['inputMapping'][incoming]=self.input_name
   input_feed={self.input_name:input_feed[incoming]}
   assert all(np.isfinite(v).all() for v in input_feed.values())
   record['pendingCall']=dict(index=record['calls'],sourceRepo=self.row['sourceRepo'],model=self.row['model'],inputs={k:dict(shape=list(v.shape),dtype=str(v.dtype),sha256=hashlib.sha256(v.tobytes()).hexdigest()) for k,v in input_feed.items()});save()
   start=time.perf_counter();result=self.real.run(output_names,input_feed,*args,**kwargs);elapsed=(time.perf_counter()-start)*1000
   assert result and all(np.isfinite(v).all() for v in result)
   with lock:
    index=record['calls'];name=f'call-{index:04d}.npz';arrays={'input_'+k:v for k,v in input_feed.items()};arrays.update({f'output_{i}':v for i,v in enumerate(result)});np.savez_compressed(out/name,**arrays)
    event=dict(index=index,sourceRepo=self.row['sourceRepo'],sourceRevision=self.row['sourceRevision'],model=self.row['model'],milliseconds=elapsed,allFinite=True,raw=name,rawSha256=sha(out/name),outputs=[dict(shape=list(v.shape),dtype=str(v.dtype)) for v in result])
    with (out/'calls.jsonl').open('a') as f:f.write(json.dumps(event)+'\n')
    self.row['calls']+=1;self.row['runMilliseconds'].append(elapsed);record['calls']+=1;record.pop('pendingCall',None);save()
   return result
 base.AXSession=TracedSession
 record['adaptations']=['Resolve the two fixed local CLIP repositories without network downloads.','Set AXERA format and each model cache directory explicitly.','Force bundled AXCL provider and capture unchanged application input/output tensors.','Map the single application input name to the compiled model input name without changing tensor values.','Run inference serially on the event-loop thread so AXCL load, execution and cleanup share the same thread context.','Stop on a load failure instead of automatically deleting a verified offline repository.']
 from immich_ml.main import app
 save()
 try:
  uvicorn.run(app,host=a.host,port=a.port,workers=1,access_log=False,log_level='info')
  for row in record['filesBefore']:
   digest=sha(root/row['modelId']/row['path']);assert digest==row['sha256'];record['filesAfter'].append(dict(row))
  for f in record['packageFiles']:assert sha(package/f['path'])==f['sha256']
  record['cleanShutdown']=True
 finally:save()
if __name__=='__main__':main()

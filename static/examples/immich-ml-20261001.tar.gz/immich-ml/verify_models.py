"""Verify the two downloaded fixed model repositories before starting Immich ML."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--check-only',action='store_true');a=p.parse_args();root=a.root.resolve();count=0
for manifest in sorted((Path(__file__).resolve().parent/'manifests').glob('*.json')):
 m=json.loads(manifest.read_text(encoding='utf-8'));base=root/m['modelId'];assert base.resolve()==base and m['complete']
 for row in m['files']:
  f=(base/row['path']).resolve();assert f.is_relative_to(base) and f.stat().st_size==row['size'],str(f)
  with f.open('rb') as s:digest=hashlib.file_digest(s,'sha256').hexdigest()
  assert digest==row['verifiedHashes']['sha256'],'SHA-256 differs: '+str(f)
  count+=1
 if not a.check_only:(base/'.validation-download.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert count==18;print('Verified',count,'fixed model files')

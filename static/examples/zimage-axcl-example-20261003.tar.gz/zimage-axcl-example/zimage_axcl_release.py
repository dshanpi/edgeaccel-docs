"""Explicit device cleanup for the pinned PyAXEngine AXCL backend.

PyAXEngine retains backend objects in a process-global list. Dropping the public
wrapper is insufficient. Keep its bookkeeping intact, invoke its cleanup once,
and record/check the real cleanup API return codes. This helper is for sequential
single-threaded model sessions; it does not modify the installed package.
"""
from pathlib import Path
import hashlib,threading
import axengine._axclrt as backend_module

EXPECTED_SOURCE='1fb5435f31cf2c402707cf1a4a03b9c05f9f7ac0ce27aa7764e6bbd66298c2e9'
if hashlib.sha256(Path(backend_module.__file__).read_bytes()).hexdigest()!=EXPECTED_SOURCE:
    raise RuntimeError('Unsupported PyAXEngine AXCL source; review cleanup API before use')

def active_models():
    return [int(b._model_id[0]) for b in backend_module._all_model_instances
            if b._model_id is not None and b._model_id[0]!=0]

def release_backend(backend):
    if threading.current_thread() is not threading.main_thread() or threading.active_count()!=1:
        raise RuntimeError('Sequential cleanup requires one Python thread')
    model_id=int(backend._model_id[0])
    if not model_id:raise RuntimeError('Model was already closed')
    real=backend_module.axclrt_lib
    status=int(real.axclrtSetCurrentContext(backend._thread_context[0]))
    if status:raise RuntimeError(f'Cannot select session context: {status:#x}')
    tracked={'axclrtEngineGetInputBufferByIndex','axclrtEngineGetOutputBufferByIndex',
             'axclrtFree','axclrtEngineDestroyIO','axclrtEngineUnload'}
    calls=[]
    class ObservedLibrary:
        def __getattr__(self,name):
            fn=getattr(real,name)
            if name not in tracked:return fn
            def invoke(*args):
                ret=fn(*args);calls.append(dict(api=name,status=int(ret)))
                return ret
            return invoke
    # The original routine clears _io and _model_id, making later atexit cleanup
    # a no-op. Retained registry objects contain metadata, not device allocations.
    backend_module.axclrt_lib=ObservedLibrary()
    try:backend._unload()
    finally:backend_module.axclrt_lib=real
    proof=dict(modelId=model_id,calls=calls,deviceHandleCleared=int(backend._model_id[0])==0,
               ioHandleCleared=backend._io is None,remainingActiveModelIds=active_models(),
               registeredMetadataObjects=len(backend_module._all_model_instances))
    if not calls or any(c['status'] for c in calls):raise RuntimeError('AXCL cleanup API failed: '+str(proof))
    if sum(c['api']=='axclrtEngineUnload' for c in calls)!=1:raise RuntimeError('Missing model unload')
    if not proof['deviceHandleCleared'] or not proof['ioHandleCleared'] or proof['remainingActiveModelIds']:
        raise RuntimeError('Device model remains active after cleanup: '+str(proof))
    return proof

def release_session(session):
    return release_backend(session._sess)

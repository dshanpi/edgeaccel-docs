# Z-Image-Turbo 固定提示词示例

在 RK3576 + AX8850 16GB M.2 算力卡上，依次运行英文、中文两条固定提示词，生成 512×512 图片。参数为 9 步去噪和随包提供的 seed 42 初始噪声。8GB 卡需要另行验证。

## 准备环境

完成 AXCL 驱动安装，确认 `axcl-smi` 能识别空闲设备。使用 Python 3.12 的独立虚拟环境，安装官方 PyAXEngine 0.1.3.rc3 发布包及本目录的 `requirements.txt`。PyAXEngine wheel 的包版本显示为 0.1.3；运行程序还会核对其 AXCL 后端源码校验值。

```bash
python3 -m venv ~/edgeaccel/zimage-env
source ~/edgeaccel/zimage-env/bin/activate
python -m pip install ~/axcl-setup/axengine-0.1.3-py3-none-any.whl \
  -r requirements.txt 'opencv-python-headless==4.11.0.86'
python -m pip check
```

模型下载分区建议至少预留 15 GiB。板载空间不足时，将 `MODEL_DIR` 指向已挂载的存储卡或 SSD。需要代理时，在当前终端设置实际可用的 `http_proxy` 和 `https_proxy`。

## 下载和运行

以下命令均在此示例目录执行：

```bash
MODEL_DIR=~/edgeaccel/models/z-image-turbo/117d8586d5c5
python download_models.py --model-dir "$MODEL_DIR"
python run_examples.py --model-dir "$MODEL_DIR" \
  --output ~/edgeaccel/results/zimage-example --check-only
export PATH=/usr/bin/axcl:$PATH
axcl-smi
python run_examples.py --model-dir "$MODEL_DIR" \
  --output ~/edgeaccel/results/zimage-example
```

下载程序核对固定版本的 102 个文件。`--check-only` 检查依赖与文件，不初始化 NPU。正式运行需要新的输出目录，避免覆盖已有结果。

程序使用本轮 AXCL 文本编码结果完成去噪与 VAE 解码。随包提供的 CPU 参考数组仅用于数值比较。此入口不支持修改提示词；替换提示词需要重新生成配套分词和 embedding 输入。

## 查看输出

运行完成后应显示两条 `Saved` 信息，图片位于：

```text
~/edgeaccel/results/zimage-example/images/sample-1/result.png
~/edgeaccel/results/zimage-example/images/sample-2/result.png
```

第一张提示词为红色小机器人在明亮温室中给绿植浇水；第二张为橙色小猫坐在蓝色花盆旁，背景为明亮温室。检查实际画面是否符合提示词。出现异常时保留输出目录，排除原因后更换输出目录再运行。

程序按顺序加载子模型，并逐个检查资源释放结果；模型文件的读取和加载会增加端到端耗时。完成后执行 `axcl-smi`，确认模型进程结束、资源释放。

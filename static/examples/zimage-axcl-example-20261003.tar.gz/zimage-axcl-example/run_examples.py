"""Run two fixed prompts through the same text and image workers used for validation."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.metadata,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'assets'
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def check_package():
    proof=read(ROOT/'example-files.json')
    for row in proof['files']:
        file=ROOT/row['path']
        if not file.resolve().is_relative_to(ROOT.resolve()) or file.stat().st_size!=row['size'] or sha(file)!=row['sha256']:
            raise RuntimeError('Example file changed: '+row['path'])
def commands(model,output):
    shared=['--model-dir',str(model),'--manifest',str(ROOT/'model-manifest.json')]
    text=[sys.executable,'-u',str(ROOT/'zimage_text_encoder_card.py'),*shared,
          '--prepared',str(ASSETS/'zimage-text-inputs-20261003'),
          '--cpu-reference',str(ASSETS/'zimage-text-reference-20261003-a'),
          '--offline-metadata',str(ASSETS/'zimage-compiled-metadata-20261003-text-c/metadata.json'),
          '--output',str(output/'text')]
    image=[sys.executable,'-u',str(ROOT/'zimage_denoise_vae_card.py'),*shared,
           '--preflight',str(ASSETS/'zimage-host-preflight-20261003'),
           '--text-stage',str(output/'text'),'--text-review',str(output/'text-stage-gate.json'),
           '--offline-metadata',str(ASSETS/'zimage-compiled-metadata-20261003-all-d/metadata.json'),
           '--output',str(output/'images')]
    return text,image
def main():
    p=argparse.ArgumentParser(description='Two fixed Z-Image AXCL examples: 512x512, 9 steps, supplied seed42 initial tensor')
    p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--check-only',action='store_true',help='Verify dependencies, package, and model files; do not initialize NPU')
    a=p.parse_args();a.model_dir=a.model_dir.resolve();a.output=a.output.resolve();check_package()
    required={'numpy':'1.26.4','ml-dtypes':'0.5.3','torch':'2.5.1','diffusers':'0.32.1','Pillow':'11.3.0','axengine':'0.1.3'}
    versions={k:importlib.metadata.version(k) for k in required}
    for key,value in required.items():
        if versions[key]!=value:raise RuntimeError(f'{key}: expected {value}, found {versions[key]}')
    backend=Path(importlib.metadata.distribution('axengine').locate_file('axengine/_axclrt.py'))
    if sha(backend)!='1fb5435f31cf2c402707cf1a4a03b9c05f9f7ac0ce27aa7764e6bbd66298c2e9':
        raise RuntimeError('Unsupported PyAXEngine AXCL backend; install the documented rc3 wheel')
    from download_models import verify
    count=verify(a.model_dir)
    print(json.dumps(dict(verifiedModelFiles=count,versions=versions,cardInferenceExecuted=False)),flush=True)
    if a.check_only:return
    a.output.mkdir(parents=True,exist_ok=False)
    text,image=commands(a.model_dir,a.output)
    env=dict(os.environ,OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    proof=dict(startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=[text,image],environment={k:env[k] for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE']},versions=versions,completed=False)
    record=a.output/'run.json';record.write_text(json.dumps(proof,indent=2)+'\n')
    for row in read(ASSETS/'zimage-text-inputs-20261003/inputs.json')['samples']:print('Prompt: '+row['prompt'],flush=True)
    try:
        subprocess.run(text,env=env,check=True)
        raw=a.output/'text/text-stage-result.json';encoded=read(raw)
        if not (encoded['completed'] and encoded['calls']==74 and len(encoded['samples'])==2 and all(r['executed'] and r['referencesReleased'] for r in encoded['sessions'])):
            raise RuntimeError('Text stage did not complete; image stage was not started')
        for row in encoded['sessions']:
            release=row['deviceRelease']
            if not (release['deviceHandleCleared'] and release['ioHandleCleared'] and not release['remainingActiveModelIds'] and all(c['status']==0 for c in release['calls'])):
                raise RuntimeError('Device cleanup failed; image stage was not started')
        for row in encoded['samples']:
            if sha(a.output/'text'/row['featuresFile'])!=row['featuresSha256']:raise RuntimeError('Text feature checksum mismatch')
        gate=dict(acceptedForImageStage=True,textStageResultSha256=sha(raw),scope='Automatic runtime integrity gate only; no image-quality acceptance implied')
        (a.output/'text-stage-gate.json').write_text(json.dumps(gate,indent=2)+'\n')
        subprocess.run(image,env=env,check=True)
        generated=read(a.output/'images/image-stage-result.json')
        if not (generated['completed'] and generated['calls']==614 and len(generated['samples'])==2):raise RuntimeError('Image stage did not complete')
        for row in generated['samples']:
            target=a.output/'images'/row['imageFile']
            if sha(target)!=row['imageSha256']:raise RuntimeError('Image checksum mismatch')
            print('Saved '+str(target),flush=True)
        proof['completed']=True
    finally:
        proof['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();record.write_text(json.dumps(proof,indent=2)+'\n')
if __name__=='__main__':main()

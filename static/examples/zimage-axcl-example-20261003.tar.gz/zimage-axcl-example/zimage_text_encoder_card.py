"""Candidate AXCL text stage plus auxiliary language-head diagnostics. Not full image generation."""
from pathlib import Path
import argparse
import datetime
import gc
import hashlib
import json
import time
import traceback

REVISION='117d8586d5c50de6f4c6e0a7058e934c207407be'
PROVIDER='AXCLRTExecutionProvider'


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(4*1024*1024),b''):digest.update(chunk)
    return digest.hexdigest()


def main():
    p=argparse.ArgumentParser()
    for name in ['model-dir','manifest','prepared','cpu-reference','offline-metadata','output']:
        p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args()
    manifest=json.loads(a.manifest.read_text())
    inputs=json.loads((a.prepared/'inputs.json').read_text())
    cpu=json.loads((a.cpu_reference/'reference.json').read_text())
    metadata=json.loads(a.offline_metadata.read_text())
    assert manifest['complete'] and cpu['complete']
    assert manifest['revision']==inputs['revision']==cpu['revision']==REVISION
    assert len(inputs['samples'])==len(cpu['samples'])==2
    assert len(metadata['files'])==37 and not metadata['inferenceExecuted']
    files={f['path']:f for f in manifest['files']}
    interfaces={f['path']:f for f in metadata['files']}
    needed=[f'text_encoder_axmodel/qwen3_p128_l{i}_together.axmodel' for i in range(36)]+['text_encoder_axmodel/qwen3_post.axmodel']
    a.output.mkdir(parents=True,exist_ok=False)
    record=dict(modelId='Z-Image-Turbo',revision=REVISION,completed=False,primaryDeploymentAccepted=False,
                scope='Text features from layers0-34, followed by separate layer35/post diagnostics; denoising and VAE are not executed here.',
                provider=PROVIDER,startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                runnerSha256=sha(__file__),phase='prehash',filesBefore=[],filesAfter=[],samples=[],sessions=[],calls=0)
    def save():
        (a.output/'text-stage-result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    def verify(key):
        record['phase']='prehash' if key=='filesBefore' else 'posthash';save()
        for name in needed:
            expected=files[name]['verifiedHashes']['sha256']
            assert interfaces[name]['sha256']==expected
            digest=sha(a.model_dir/name)
            assert digest==expected,name
            record[key].append(dict(path=name,sha256=digest))
            save()
        save()
    save()
    import numpy as np
    import ml_dtypes
    import axengine
    from zimage_axcl_release import release_session
    bf=np.dtype(ml_dtypes.bfloat16)
    assert bf.itemsize==2

    def dtype_name(dtype):
        dtype=np.dtype(dtype)
        return {bf:'BFLOAT16',np.dtype('uint32'):'UINT32',np.dtype('float32'):'FLOAT'}[dtype]

    def compare(name, value, expected):
        actual=value.astype(np.float32)
        expected=expected.astype(np.float32)
        assert actual.shape==expected.shape and np.isfinite(actual).all() and np.isfinite(expected).all()
        diff=actual.astype(np.float64)-expected.astype(np.float64)
        left,right=actual.ravel().astype(np.float64),expected.ravel().astype(np.float64)
        denom=float(np.linalg.norm(left)*np.linalg.norm(right))
        return dict(name=name,shape=list(actual.shape),rmse=float(np.sqrt(np.mean(diff*diff))),
                    maxAbs=float(np.max(np.abs(diff))),cosine=float(np.dot(left,right)/denom) if denom else None,
                    interpretation='Measured numerical difference only; no quality acceptance threshold inferred.')

    def run_one(name, feed, group, sample_index):
        meta=interfaces[name]
        def declared(which):
            values=meta[which]
            if group:
                return {v['name'][:-2]:v for v in values if v['name'].endswith('_1')}
            return {v['name']:v for v in values}
        wanted_in,wanted_out=declared('inputs'),declared('outputs')
        assert set(feed)==set(wanted_in)
        session=None
        row=dict(model=name,group=group,sample=sample_index,sha256=meta['sha256'],executed=False,referencesReleased=False)
        record['sessions'].append(row);save()
        try:
            t=time.perf_counter()
            session=axengine.InferenceSession(str(a.model_dir/name),providers=[PROVIDER])
            assert session.get_providers() in (PROVIDER,[PROVIDER])
            row['loadSeconds']=time.perf_counter()-t
            actual_in=session.get_inputs(shape_group=group)
            actual_out=session.get_outputs(shape_group=group)
            def canonical(arg, expected):
                name=arg.name if arg.name in expected else arg.name[:-2] if arg.name.endswith('_1') else arg.name
                assert name in expected,(arg.name,expected)
                spec=expected[name]
                assert list(arg.shape)==spec['shape'] and dtype_name(arg.dtype)==spec['dtype'],arg.name
                return name
            in_names={canonical(v,wanted_in):v.name for v in actual_in}
            out_names={v.name:canonical(v,wanted_out) for v in actual_out}
            assert set(in_names)==set(wanted_in) and set(out_names.values())==set(wanted_out)
            row.update(actualInputNames=in_names,actualOutputNames=out_names)
            actual_feed={}
            for name,value in feed.items():
                spec=wanted_in[name]
                assert list(value.shape)==spec['shape'] and dtype_name(value.dtype)==spec['dtype']
                assert np.isfinite(value.astype(np.float32)).all()
                actual_feed[in_names[name]]=np.ascontiguousarray(value)
            row['inputHashes']={n:hashlib.sha256(v.tobytes()).hexdigest() for n,v in actual_feed.items()}
            save();t=time.perf_counter()
            values=session.run(None,actual_feed,shape_group=group)
            row['runMilliseconds']=(time.perf_counter()-t)*1000
            assert len(values)==len(actual_out)
            result={}
            for spec,value in zip(actual_out,values):
                assert list(value.shape)==list(spec.shape) and value.dtype==np.dtype(spec.dtype)
                assert np.isfinite(value.astype(np.float32)).all()
                result[out_names[spec.name]]=value.copy()
            row.update(executed=True,outputHashes={n:hashlib.sha256(v.tobytes()).hexdigest() for n,v in result.items()})
            record['calls']+=1
            return result
        except BaseException:
            row['failure']=traceback.format_exc()
            raise
        finally:
            if session is not None:
                row["deviceRelease"] = release_session(session)
                del session
                gc.collect()
                row['referencesReleased']=True
            save()

    failure=None
    try:
        verify('filesBefore')
        record['phase']='text-encoding';save()
        for number,(prepared,reference) in enumerate(zip(inputs['samples'],cpu['samples']),1):
            assert prepared['prompt']==reference['prompt'] and reference['companionEmbeddingRowsMatchOriginal']
            path=a.prepared/prepared['file']
            assert sha(path)==prepared['fileSha256']
            with np.load(path,allow_pickle=False) as archive:
                x=archive['input_bits'].view(bf).copy()
                mask=archive['mask_bits'].view(bf).copy()
                indices=archive['indices'].copy()
                key=archive['K_cache_bits'].view(bf).copy()
                value=archive['V_cache_bits'].view(bf).copy()
            assert hashlib.sha256(x.tobytes()).hexdigest()==prepared['inputBitsSha256']
            result=dict(prompt=prepared['prompt'],realTokens=prepared['realTokens'],comparisons=[])
            def cpu_array(filename,expected_sha):
                source=a.cpu_reference/filename
                assert sha(source)==expected_sha
                return np.load(source,allow_pickle=False)
            features=cpu_array(reference['outputFile'],reference['outputSha256'])
            auxiliary={r['name']:cpu_array(r['file'],r['sha256']) for r in reference['auxiliaryReferences']}
            for layer in range(36):
                name=f'text_encoder_axmodel/qwen3_p128_l{layer}_together.axmodel'
                outputs=run_one(name,dict(input=x,mask=mask,indices=indices,K_cache=key,V_cache=value),1,number)
                x=outputs['output']
                if layer==34:
                    target=a.output/f'prompt-{number}-features.npy'
                    np.save(target,x[0].astype(np.float32))
                    result.update(featuresFile=target.name,featuresSha256=sha(target),featuresSource='layer34 output before layer35 and final norm')
                    result['comparisons'].append(compare('image_text_features',x[0],features))
            result['comparisons'].append(compare('aux_layer35',x,auxiliary['after35']))
            position=prepared['realTokens']-1
            outputs=run_one('text_encoder_axmodel/qwen3_post.axmodel',dict(input=x[:,position:position+1].copy()),0,number)
            result['comparisons'].append(compare('aux_final_norm',outputs['output_norm'],auxiliary['finalNorm'][:,position:position+1]))
            result['comparisons'].append(compare('aux_logits',outputs['output'].reshape(-1),auxiliary['lastRealTokenLogits']))
            for name,value in outputs.items():
                np.save(a.output/f'prompt-{number}-aux-{name}.npy',value.astype(np.float32))
            record['samples'].append(result);save()
        assert record['calls']==74
    except BaseException as error:
        failure=error;record['failure']=traceback.format_exc();save()
    finally:
        verify('filesAfter')
        record['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    if failure:raise failure
    record.update(completed=True,phase='completed');save()


if __name__=='__main__':main()

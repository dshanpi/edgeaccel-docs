"""Download only the pinned Z-Image deployment files; verify SHA256 before use."""
from pathlib import Path
import argparse,hashlib,json
ROOT=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def model_file(root,name):
    target=root/name
    if not target.resolve().is_relative_to(root.resolve()):raise ValueError('Unsafe model path')
    return target
def verify(root):
    m=json.loads((ROOT/'model-manifest.json').read_text())
    for row in m['files']:
        target=model_file(root,row['path'])
        if not target.is_file() or target.stat().st_size!=row['size'] or sha(target)!=row['verifiedHashes']['sha256']:
            raise RuntimeError('Missing or mismatched file: '+row['path'])
    return len(m['files'])
def main():
    p=argparse.ArgumentParser();p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--verify-only',action='store_true');a=p.parse_args()
    m=json.loads((ROOT/'model-manifest.json').read_text());a.model_dir.mkdir(parents=True,exist_ok=True)
    if not a.verify_only:
        from huggingface_hub import hf_hub_download
        for index,row in enumerate(m['files'],1):
            target=model_file(a.model_dir,row['path'])
            good=target.is_file() and target.stat().st_size==row['size'] and sha(target)==row['verifiedHashes']['sha256']
            if not good:
                hf_hub_download(repo_id=m['repo'],revision=m['revision'],filename=row['path'],local_dir=a.model_dir,force_download=target.exists())
                if not target.is_file() or sha(target)!=row['verifiedHashes']['sha256']:raise RuntimeError('Checksum mismatch: '+row['path'])
            print(f'[{index}/{len(m["files"])}] OK {row["path"]}',flush=True)
    print(f'Verified {verify(a.model_dir)} model files')
if __name__=='__main__':main()

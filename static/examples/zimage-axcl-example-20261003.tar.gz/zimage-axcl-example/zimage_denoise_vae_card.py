"""Candidate full AXCL denoising/VAE stage fed by the reviewed AXCL text-stage artifacts."""
from pathlib import Path
import argparse
import ast
import datetime
import gc
import hashlib
import importlib.metadata
import json
import time
import traceback
import subprocess
import re

REVISION='117d8586d5c50de6f4c6e0a7058e934c207407be'
PROVIDER='AXCLRTExecutionProvider'


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda:stream.read(4*1024*1024),b''):digest.update(part)
    return digest.hexdigest()


def main():
    p=argparse.ArgumentParser()
    for name in ['model-dir','manifest','preflight','text-stage','text-review','offline-metadata','output']:
        p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args()
    manifest=json.loads(a.manifest.read_text())
    prep=json.loads((a.preflight/'preflight.json').read_text())
    text=json.loads((a.text_stage/'text-stage-result.json').read_text())
    review=json.loads(a.text_review.read_text())
    metadata=json.loads(a.offline_metadata.read_text())
    assert manifest['complete'] and prep['passedHostPreprocessing'] and text['completed']
    assert manifest['revision']==prep['revision']==text['revision']==REVISION
    assert text['provider']==PROVIDER and text['calls']==74 and len(text['samples'])==2
    assert review['acceptedForImageStage'] and review['textStageResultSha256']==sha(a.text_stage/'text-stage-result.json')
    assert len(metadata['files'])==73 and not metadata['inferenceExecuted']
    files={f['path']:f for f in manifest['files']}
    interfaces={f['path']:f for f in metadata['files']}
    cfg=prep['configSubgraphs']
    assert len(cfg)==33
    auto='transformer_axmodel/auto_00_model_layers_29_Add_4_output_0_to_sample_auto.axmodel'
    vaes=['vae_model/vae_decoder.axmodel','VideoX-Fun/vae_decoder.axmodel']
    needed=[row['weight'] for row in cfg]+[auto]+vaes
    assert len(needed)==36 and files[vaes[0]]['verifiedHashes']['sha256']==files[vaes[1]]['verifiedHashes']['sha256']
    for name in needed:
        assert interfaces[name]['sha256']==files[name]['verifiedHashes']['sha256']
    a.output.mkdir(parents=True,exist_ok=False)
    result=dict(modelId='Z-Image-Turbo',revision=REVISION,completed=False,primaryDeploymentAccepted=False,
                scope='Full9-step AXCL denoising and VAE from separately reviewed AXCL text features; visual quality and controller health review are still required.',
                startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),provider=PROVIDER,
                seed=42,steps=9,size=[512,512],sessionPolicy='one active AXModel session; no session cache',
                runnerSha256=sha(__file__),textStageResultSha256=sha(a.text_stage/'text-stage-result.json'),
                phase='prehash',calls=0,models={},filesBefore=[],filesAfter=[],samples=[])
    def save():
        (a.output/'image-stage-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    def verify(key):
        result['phase']='prehash' if key=='filesBefore' else 'posthash';save()
        for name in needed:
            digest=sha(a.model_dir/name)
            assert digest==files[name]['verifiedHashes']['sha256'],name
            result[key].append(dict(path=name,sha256=digest))
            save()
        save()
    save()
    import numpy as np
    import torch
    from diffusers import FlowMatchEulerDiscreteScheduler
    from diffusers.image_processor import VaeImageProcessor
    from diffusers.utils.torch_utils import randn_tensor
    import axengine
    from zimage_axcl_release import release_session
    assert importlib.metadata.version('diffusers')=='0.32.1'
    torch.set_num_threads(2)
    torch.set_grad_enabled(False)
    result['dependencies']={n:importlib.metadata.version(n) for n in ['torch','diffusers','numpy','Pillow']}
    result['sourceFilesVerified']=[]
    for source_item in prep['sourceFiles']:
        name=source_item['path']
        digest=sha(a.model_dir/name)
        assert digest==source_item['verifiedHashes']['sha256']==files[name]['verifiedHashes']['sha256'],name
        result['sourceFilesVerified'].append(dict(path=name,sha256=digest))
    save()
    source=a.model_dir/'VideoX-Fun/examples/z_image_fun/launcher_axmodel.py'
    wanted={'prepare_latents','calculate_shift','retrieve_timesteps'}
    functions=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in wanted]
    assert {n.name for n in functions}==wanted
    module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),*functions],type_ignores=[])
    ast.fix_missing_locations(module)
    original=dict(torch=torch,randn_tensor=randn_tensor,VAE_SCALE_FACTOR=8)
    exec(compile(module,str(source),'exec'),original)
    scheduler_dir=a.model_dir/'VideoX-Fun/models/Diffusion_Transformer/Z-Image-Turbo/scheduler'
    processor=VaeImageProcessor(vae_scale_factor=16)
    schedule=[]
    for row in cfg:
        meta=interfaces[row['weight']]
        actual_names=[v['name'] for v in meta['inputs']]
        assert len(actual_names)==len(row['inputs']) and set(actual_names)==set(row['inputs'])
        assert [v['name'] for v in meta['outputs']]==row['outputs']
        schedule.append(dict(weight=row['weight'],inputs=row['inputs'],outputs=row['outputs']))
    schedule.append(dict(weight=auto,inputs=[v['name'] for v in interfaces[auto]['inputs']],outputs=[v['name'] for v in interfaces[auto]['outputs']]))
    assert schedule[-1]['outputs']==['sample']
    assert len(schedule)==34

    def run_model(name,feed,sample,step):
        meta=interfaces[name]
        wanted_in={v['name']:v for v in meta['inputs']}
        wanted_out={v['name']:v for v in meta['outputs']}
        assert set(feed)==set(wanted_in)
        session=None
        row=dict(index=result['calls'],model=name,sample=sample,step=step,group=0,executed=False)
        try:
            t=time.perf_counter()
            session=axengine.InferenceSession(str(a.model_dir/name),providers=[PROVIDER])
            assert session.get_providers() in (PROVIDER,[PROVIDER])
            row['loadSeconds']=time.perf_counter()-t
            actual_in=session.get_inputs(shape_group=0)
            actual_out=session.get_outputs(shape_group=0)
            assert {v.name for v in actual_in}==set(wanted_in) and {v.name for v in actual_out}==set(wanted_out)
            for actual,wanted in [(actual_in,wanted_in),(actual_out,wanted_out)]:
                for v in actual:
                    expected=wanted[v.name]
                    assert list(v.shape)==expected['shape'] and expected['dtype']=='FLOAT' and np.dtype(v.dtype)==np.dtype('float32')
            for key,value in feed.items():
                assert list(value.shape)==wanted_in[key]['shape'] and value.dtype==np.float32 and np.isfinite(value).all()
            row['inputs']={k:dict(shape=list(v.shape),sha256=hashlib.sha256(v.tobytes()).hexdigest()) for k,v in feed.items()}
            t=time.perf_counter()
            values=session.run(None,{k:np.ascontiguousarray(v) for k,v in feed.items()},shape_group=0)
            row['runMilliseconds']=(time.perf_counter()-t)*1000
            assert len(values)==len(actual_out)
            outputs={}
            for v,array in zip(actual_out,values):
                assert list(array.shape)==list(v.shape) and array.dtype==np.float32 and np.isfinite(array).all()
                outputs[v.name]=array.copy()
            row.update(executed=True,outputs={k:dict(shape=list(v.shape),sha256=hashlib.sha256(v.tobytes()).hexdigest()) for k,v in outputs.items()})
            result['calls']+=1
            save()
            stats=result['models'].setdefault(name,dict(sha256=meta['sha256'],calls=0,runMilliseconds=0.0,loadSeconds=0.0))
            stats['calls']+=1;stats['runMilliseconds']+=row['runMilliseconds'];stats['loadSeconds']+=row['loadSeconds']
            return outputs
        except BaseException:
            row['failure']=traceback.format_exc()
            raise
        finally:
            if session is not None:
                row["deviceRelease"] = release_session(session)
                del session
                gc.collect()
                row['referencesReleased']=True
            with (a.output/'calls.jsonl').open('a') as log:
                log.write(json.dumps(row)+'\n');log.flush()

    def idle_checkpoint(sample, step):
        # Synchronous query between steps, after every owned model has unloaded.
        p=subprocess.run(['/usr/bin/axcl/axcl-smi'],capture_output=True,text=True,timeout=20)
        checkpoint=dict(sample=sample,step=step,exitCode=p.returncode,stdout=p.stdout,stderr=p.stderr)
        result.setdefault('idleCheckpoints',[]).append(checkpoint);save()
        assert p.returncode==0 and re.search(r'18 MiB\s*/\s*15232 MiB',p.stdout)
        assert int(re.search(r'(\d+)C',p.stdout)[1])<75

    failure=None
    try:
        verify('filesBefore')
        for number,(encoded,prompt) in enumerate(zip(text['samples'],prep['samples']),1):
            assert encoded['prompt']==prompt['prompt'] and encoded['featuresSource']=='layer34 output before layer35 and final norm'
            feature_file=a.text_stage/encoded['featuresFile']
            assert sha(feature_file)==encoded['featuresSha256']
            features=np.load(feature_file,allow_pickle=False)
            assert features.shape==(128,2560) and features.dtype==np.float32 and np.isfinite(features).all()
            sampler=FlowMatchEulerDiscreteScheduler.from_pretrained(scheduler_dir,local_files_only=True)
            reference_latent=a.preflight/'seed42-initial-latents.npy'
            assert sha(reference_latent)==prep['initialLatentFileSha256']
            initial=np.load(reference_latent,allow_pickle=False)
            assert initial.shape==(1,16,64,64) and initial.dtype==np.float32 and np.isfinite(initial).all()
            latents=torch.from_numpy(initial.copy())
            result.update(initialLatentSource='Pinned seed42 host tensor loaded from NPY',initialLatentFileSha256=sha(reference_latent))
            mu=original['calculate_shift'](1024,sampler.config.get('base_image_seq_len',256),sampler.config.get('max_image_seq_len',4096),sampler.config.get('base_shift',.5),sampler.config.get('max_shift',1.15))
            timesteps=original['retrieve_timesteps'](sampler,9,torch.device('cpu'),mu=mu)
            assert timesteps.tolist()==prep['scheduler']['timesteps']
            sample_dir=a.output/f'sample-{number}';sample_dir.mkdir()
            sample_result=dict(prompt=prompt['prompt'],textFeatureSha256=encoded['featuresSha256'],steps=[])
            start=time.perf_counter()
            result['samplesInProgress']={str(number):sample_result};save()
            for step,timestep in enumerate(timesteps):
                result.update(phase='denoising',currentSample=number,currentStep=step);save()
                tensors={'latent_model_input':latents.unsqueeze(2).numpy(),'prompt_embeds':features[None],
                         'timestep':((1000-timestep.expand(1))/1000).numpy()}
                for index,subgraph in enumerate(schedule):
                    assert set(subgraph['inputs'])<=set(tensors)
                    outputs=run_model(subgraph['weight'],{k:tensors[k] for k in subgraph['inputs']},number,step)
                    assert set(outputs)==set(subgraph['outputs'])
                    tensors.update(outputs)
                    # Preserve only tensors consumed later, plus the final output.
                    remaining={n for later in schedule[index+1:] for n in later['inputs']}|{'sample'}
                    tensors={k:v for k,v in tensors.items() if k in remaining}
                model_out=tensors['sample']
                assert model_out.shape==(1,16,1,64,64)
                noise=-torch.from_numpy(np.squeeze(model_out,axis=2))
                latents=sampler.step(noise,timestep,latents,return_dict=False)[0]
                assert torch.isfinite(latents).all()
                target=sample_dir/f'latent-step-{step+1}.npy';np.save(target,latents.numpy())
                sample_result['steps'].append(dict(index=step,timestep=float(timestep),latentFile=target.name,sha256=sha(target),modelOutputSha256=hashlib.sha256(model_out.tobytes()).hexdigest()))
                idle_checkpoint(number,step)
                save()
            decoder=((latents/0.3611)+0.1159).numpy()
            np.save(sample_dir/'decoder-input.npy',decoder)
            vae=vaes[number-1]
            result['phase']='vae-decode';save()
            image=run_model(vae,{'latents':decoder},number,'vae')['images']
            assert image.shape==(1,3,512,512)
            idle_checkpoint(number,'vae')
            np.save(sample_dir/'vae-output.npy',image)
            picture=processor.postprocess(torch.from_numpy(image),output_type='pil')[0]
            assert picture.size==(512,512)
            output=sample_dir/'result.png';picture.save(output)
            sample_result.update(imageFile=str(output.relative_to(a.output)),imageSha256=sha(output),
                                 elapsedSeconds=time.perf_counter()-start,vaeWeight=vae,
                                 rawVae=dict(minimum=float(image.min()),maximum=float(image.max()),mean=float(image.mean()),std=float(image.std())),
                                 visualReviewCompleted=False)
            result['samples'].append(sample_result);save()
        assert result['calls']==614 and set(result['models'])==set(needed)
        assert result['samples'][0]['imageSha256']!=result['samples'][1]['imageSha256'], 'Different prompts produced byte-identical images'
    except BaseException as error:
        failure=error;result['failure']=traceback.format_exc();save()
    finally:
        verify('filesAfter');result['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    if failure:raise failure
    result.pop('samplesInProgress',None)
    result.update(completed=True,phase='completed');save()


if __name__=='__main__':main()

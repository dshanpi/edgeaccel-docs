from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve();m=json.loads(Path(__file__).with_name('download-manifest.json').read_text())
for f in m['files']:
 p=(root/f['path']).resolve();assert p.is_relative_to(root) and p.stat().st_size==f['size'],f['path']
 with p.open('rb') as s:assert hashlib.file_digest(s,'sha256').hexdigest()==f['verifiedHashes']['sha256'],f['path']
print('Verified 53 model files')

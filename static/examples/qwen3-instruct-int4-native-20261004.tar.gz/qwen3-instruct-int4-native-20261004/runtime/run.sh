#!/bin/bash
set -euo pipefail
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
MODEL_DIR=$(realpath -e -- "${1:?Usage: run.sh MODEL_DIR PROMPT_FILE OUTPUT_JSON}")
PROMPT_FILE=$(realpath -e -- "${2:?UTF-8 prompt file required}")
OUTPUT_JSON=$(realpath -m -- "${3:?Output JSON file required}")
WEIGHTS="$MODEL_DIR/Qwen3-4B-Instruct-2507-GPTQ-Int4-context-4k-prefill-3584"
exec "$HERE/main_axcl_aarch64" \
  --template_filename_axmodel "$WEIGHTS/qwen3_p256_l%d_together.axmodel" \
  --filename_post_axmodel "$WEIGHTS/qwen3_post.axmodel" \
  --filename_tokens_embed "$WEIGHTS/model.embed_tokens.weight.bfloat16.bin" \
  --filename_tokenizer_model "$HERE/tokenizer.txt" \
  --post_config_path "$HERE/post_config.json" \
  --prompt-file "$PROMPT_FILE" --output-json "$OUTPUT_JSON"

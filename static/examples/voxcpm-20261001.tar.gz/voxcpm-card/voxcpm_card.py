"""Run fixed official VoxCPM Python pipeline with explicit AXCL and evidence."""
import argparse,hashlib,json,os,sys,time,traceback
from pathlib import Path
REV='4362ceca842ace15a8f7e67a2302f72143a60f06'
PROVIDER='AXCLRTExecutionProvider'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--text',default='Streaming text to speech is easy with VoxCPM!');p.add_argument('--reference-audio',default='assets/en_woman1.mp3');p.add_argument('--reference-text',default='But many of these southern girls have the same trouble, said Holly.');a=p.parse_args();assert a.text.strip() and a.reference_text.strip()
 root=a.model_dir.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 manifest_path=root/'.validation-download.json'
 if not manifest_path.is_file():manifest_path=Path(__file__).resolve().parent/'download-manifest.json'
 manifest=json.loads(manifest_path.read_text());assert manifest['complete'] and manifest['revision']==REV and len(manifest['files'])==97
 files={f['path']:f for f in manifest['files']};assert a.reference_audio in files and (root/a.reference_audio).resolve().is_relative_to(root);source=json.loads((a.source/'source-proof.json').read_text())
 rec=dict(completed=False,modelId='VoxCPM',revision=REV,provider=PROVIDER,sourceRevision=source['revision'],runnerSha256=sha(__file__),filesBefore=[],filesAfter=[],sourceBefore=[],sourceAfter=[],sessions=[],totalCalls=0,stopDecisions=[])
 def save():(out/'deployment-result.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf-8')
 def verify(key,src,items):
  for f in items:
   name=f['path'];expected=f.get('sha256') or f['verifiedHashes']['sha256'];actual=sha(src/name);rec[key].append(dict(path=name,sha256=actual,expectedSha256=expected,matched=actual==expected));save();assert actual==expected,name
 save();verify('filesBefore',root,manifest['files']);verify('sourceBefore',a.source,source['files'])
 os.environ.update(AX_INFER='True',AXMODEL_DIR=str(root),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',DEBUG_TIME='false')
 import numpy as np,torch,soundfile as sf,axengine,onnxruntime as ort
 torch.set_num_threads(2);torch.manual_seed(1234);np.random.seed(1234)
 import importlib.metadata as md
 rec['versions']={n:md.version(n) for n in ['numpy','torch','torchaudio','transformers','tokenizers','einops','pydantic','tqdm','onnxruntime','ml-dtypes','soundfile','librosa','dill']}
 assert PROVIDER in axengine.get_available_providers()
 original_ax=axengine.InferenceSession;original_ort=ort.InferenceSession
 live=[]
 def nodes(items,ax):return [dict(name=n.name,shape=list(n.shape),dtype=str(n.dtype if ax else n.type)) for n in items]
 def record_run(session,names,feeds,shape_group,run,ax):
  audit=session.audit;group=str(shape_group);ins=session.get_inputs(shape_group=shape_group) if ax else session.get_inputs();outs=session.get_outputs(shape_group=shape_group) if ax else session.get_outputs()
  if group not in audit['groups']:audit['groups'][group]=dict(inputs=nodes(ins,ax),outputs=nodes(outs,ax));save()
  assert set(feeds)=={n.name for n in ins}
  if ax:
   for n in ins:
    v=feeds[n.name];assert v.dtype==np.dtype(n.dtype),(n.name,v.dtype,n.dtype)
    if np.prod(n.shape)>0:assert tuple(v.shape)==tuple(n.shape),(n.name,v.shape,n.shape)
  t=time.perf_counter();values=run();ms=1000*(time.perf_counter()-t)
  wanted=outs if names is None else [next(n for n in outs if n.name==s) for s in names]
  assert len(values)==len(wanted)
  entry=dict(index=rec['totalCalls'],model=audit['model'],backend=audit['backend'],shapeGroup=shape_group,milliseconds=ms,outputs=[])
  for n,v in zip(wanted,values):
   v=np.asarray(v);finite=bool(np.isfinite(v.astype(np.float32)).all());entry['outputs'].append(dict(name=n.name,shape=list(v.shape),dtype=str(v.dtype),sha256=hashlib.sha256(v.tobytes()).hexdigest(),allFinite=finite));assert finite,(audit['model'],n.name)
  with (out/'calls.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(entry)+'\n')
  audit['calls']+=1;audit['runMilliseconds'].append(ms);rec['totalCalls']+=1
  if rec['totalCalls']%100==0:save()
  return values
 class AXSession(original_ax):
  def __init__(self,path,*args,**kwargs):
   name=Path(path).resolve().relative_to(root).as_posix();assert name in files and not args
   kwargs['providers']=[PROVIDER]
   self.audit=dict(model=name,backend=PROVIDER,sha256=files[name]['verifiedHashes']['sha256'],groups={},calls=0,runMilliseconds=[],allFinite=True)
   rec['sessions'].append(self.audit);save();super().__init__(path,**kwargs);assert self.get_providers() in [PROVIDER,[PROVIDER]];live.append(self)
  def run(self,names,feeds,shape_group=0):return record_run(self,names,feeds,shape_group,lambda:super(AXSession,self).run(names,feeds,shape_group=shape_group),True)
 class ORTSession:
  def __init__(self,path,*args,**kwargs):
   name=Path(path).resolve().relative_to(root).as_posix();assert name in files and not args and not kwargs
   opts=ort.SessionOptions();opts.intra_op_num_threads=2;opts.inter_op_num_threads=1;opts.enable_cpu_mem_arena=False
   self.session=original_ort(str(path),sess_options=opts,providers=['CPUExecutionProvider']);assert self.session.get_providers()==['CPUExecutionProvider']
   self.audit=dict(model=name,backend='CPUExecutionProvider',sha256=files[name]['verifiedHashes']['sha256'],groups={},calls=0,runMilliseconds=[],allFinite=True);rec['sessions'].append(self.audit);save()
  def get_inputs(self):return self.session.get_inputs()
  def get_outputs(self):return self.session.get_outputs()
  def run(self,names,feeds):return record_run(self,names,feeds,0,lambda:self.session.run(names,feeds),False)
 axengine.InferenceSession=AXSession;ort.InferenceSession=ORTSession
 sys.path.insert(0,str(a.source/'src'))
 from voxcpm import VoxCPM
 try:
  t=time.perf_counter();model=VoxCPM.from_pretrained(str(root/'VoxCPM-0.5B'),load_denoiser=False,optimize=False,local_files_only=True);rec['loadSeconds']=time.perf_counter()-t
  original_stop=model.tts_model.predict_stop
  def trace_stop(x):
   value=original_stop(x);rec['stopDecisions'].append(int(value[0].cpu().item()));save();return value
  model.tts_model.predict_stop=trace_stop
  text=a.text;prompt=a.reference_text
  rec.update(text=text,promptText=prompt,promptAudio=a.reference_audio,seed=1234,maxLength=128,inferenceTimesteps=10,cfgValue=2,normalize=False,denoise=False,retryBadcase=False)
  chunks=[];t=time.perf_counter()
  for chunk in model.generate_streaming(text=text,prompt_wav_path=str(root/rec['promptAudio']),prompt_text=prompt,cfg_value=2,inference_timesteps=10,max_length=128,normalize=False,denoise=False,retry_badcase=False):
   assert np.isfinite(chunk).all() and chunk.ndim==1;chunks.append(chunk.copy());print('Generated chunk',len(chunks),len(chunk),flush=True)
  rec['generationSecondsIncludingTrace']=time.perf_counter()-t;wav=np.concatenate(chunks)
  rec['naturalStop']=len(rec['stopDecisions'])<128 and rec['stopDecisions'][-1]==1 and len(rec['stopDecisions'])>3
  assert rec['naturalStop'],'Maximum length reached without model stop'
  assert wav.size and np.isfinite(wav).all();sf.write(out/'generated.wav',wav,16000,subtype='FLOAT');np.save(out/'generated.npy',wav)
  rec['audio']=dict(samples=int(wav.size),sampleRate=16000,seconds=wav.size/16000,channels=1,finite=True,peak=float(np.max(np.abs(wav))),rms=float(np.sqrt(np.mean(wav**2))),sha256=sha(out/'generated.wav'),chunks=len(chunks))
  assert rec['audio']['rms']>1e-5 and rec['audio']['seconds']>0.5
  rec['inferenceCompleted']=True
 except BaseException:
  rec['error']=traceback.format_exc();raise
 finally:
  save()
  for s in live:
   if getattr(s,'_sess',None) is not None:s._sess._unload();s.audit['unloaded']=True
  verify('filesAfter',root,manifest['files']);verify('sourceAfter',a.source,source['files']);save()
 rec['completed']=True;save();print(json.dumps(dict(completed=True,audio=rec['audio'],totalCalls=rec['totalCalls'])),flush=True)
if __name__=='__main__':main()

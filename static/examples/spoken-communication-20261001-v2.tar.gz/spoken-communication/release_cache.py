"""Verify downloaded model files, then release their Linux file-cache pages after services stop."""
import argparse,hashlib,json,os,socket
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--app-dir',type=Path,required=True);p.add_argument('--companion-dir',type=Path,required=True);p.add_argument('--output',type=Path);a=p.parse_args()
for port in (8000,12345):
 with socket.socket() as sock:
  assert sock.connect_ex(('127.0.0.1',port))!=0,'Stop the local API and tokenizer services first'
assert hasattr(os,'posix_fadvise'),'Linux posix_fadvise is required'
result=dict(completed=False,scope='Only files from the two package manifests; no global cache operation or file modification',files=[],meminfoBefore=Path('/proc/meminfo').read_text())
for folder,name in [(a.app_dir,'download-manifest.json'),(a.companion_dir,'companion-manifest.json')]:
 root=folder.resolve();manifest=json.loads((Path(__file__).parent/name).read_text())
 for entry in manifest['files']:
  path=(root/entry['path']).resolve();assert path.is_relative_to(root) and path.is_file() and path.stat().st_size==entry['size']
  with path.open('rb') as stream:
   digest=hashlib.file_digest(stream,'sha256').hexdigest();assert digest==entry['verifiedHashes']['sha256'],entry['path']
   os.posix_fadvise(stream.fileno(),0,0,os.POSIX_FADV_DONTNEED)
  result['files'].append(dict(modelId=manifest['modelId'],path=entry['path'],sha256=digest,cacheReleaseAdvised=True))
result.update(completed=True,meminfoAfter=Path('/proc/meminfo').read_text())
if a.output:
 assert not a.output.exists();a.output.write_text(json.dumps(result,indent=2)+'\n','utf-8')
print('Verified and requested file-cache release for',len(result['files']),'files; files remain on disk')

#!/usr/bin/env python3
"""Verify the pinned repository and prepare a separate directory for its original scripts."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,sys

def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model-dir',required=True,type=Path)
    p.add_argument('--runtime-dir',required=True,type=Path)
    p.add_argument('--check-only',action='store_true')
    a=p.parse_args();base=Path(__file__).resolve().parent
    model=a.model_dir.expanduser().resolve(strict=True);runtime=a.runtime_dir.expanduser().resolve()
    manifest=json.loads((base/'download-manifest.json').read_text('utf-8'))
    assert manifest['repo']=='AXERA-TECH/Xiaomi-MiMo-VL-Miloco-7B-AX650-GPTQ-Int4'
    assert manifest['revision']=='839273460d343a02f2e88a0cfe059f8ec78a50ea' and len(manifest['files'])==75
    assert not runtime.is_relative_to(model) and not model.is_relative_to(runtime),'Use a separate runtime directory'
    assert not runtime.exists(),'Runtime directory already exists; select a new directory'
    for f in manifest['files']:
        path=model/f['path'];assert path.resolve().is_relative_to(model)
        assert path.is_file() and path.stat().st_size==f['size'] and digest(path)==f['verifiedHashes']['sha256'],f['path']
    config=base/'post_config.json'
    assert digest(config)=='7cd05fda186c94658893a58b9cb4f18f4747e932ecd52f8f449ae862265078e0'
    if a.check_only:
        print(json.dumps(dict(modelFilesVerified=75,revision=manifest['revision'],runtimeCreated=False)));return
    runtime.mkdir(parents=True)
    try:
        top={f['path'].split('/')[0] for f in manifest['files']}
        for name in sorted(top-{'main_axcl_aarch64'}):
            source=model/name;(runtime/name).symlink_to(source,target_is_directory=source.is_dir())
        shutil.copyfile(model/'main_axcl_aarch64',runtime/'main_axcl_aarch64')
        (runtime/'main_axcl_aarch64').chmod(0o755)
        shutil.copyfile(config,runtime/'post_config.json')
        assert digest(runtime/'main_axcl_aarch64')==digest(model/'main_axcl_aarch64')
        assert digest(runtime/'post_config.json')==digest(config)
        record=dict(modelFilesVerified=75,revision=manifest['revision'],runtime=str(runtime),modelDirectory=str(model),originalScriptsUnmodified=True,postConfigSha256=digest(config),binarySha256=digest(runtime/'main_axcl_aarch64'))
        (runtime/'prepared-runtime.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(record))
    except BaseException:
        print('Preparation failed; keep this directory for inspection and choose a new directory after correcting the cause.',file=sys.stderr)
        raise

if __name__=='__main__':main()

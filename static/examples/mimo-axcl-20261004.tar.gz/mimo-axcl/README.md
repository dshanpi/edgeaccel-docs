# MiMo AXCL 运行目录准备工具

在连接16GB算力卡的RK3576主机运行。原模型固定版本为839273460d343a02f2e88a0cfe059f8ec78a50ea。

```bash
python3 prepare_runtime.py --model-dir /模型目录 --runtime-dir ~/edgeaccel/mimo-runtime
cd ~/edgeaccel/mimo-runtime
bash run_image_axcl_aarch64.sh
```

准备工具逐一校验75个文件，保留模型目录，建立独立运行目录并放置贪心采样配置。`--runtime-dir`必须为新目录。原版分词服务需另行启动，并可通过板端127.0.0.1:8080访问。使用图片入口时运行tokenizer_image.py，视频入口则使用tokenizer_video.py。

当前例子仅验证16GB基本运行，输出存在识别偏差；8GB和完整数据集质量尚未验收。

"""Fixed official SmolLM3 inference with explicit AXCL and auditable text outputs."""
import argparse,hashlib,json,sys,time,traceback,importlib.util,os
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
REV='a00aaa540d2c0dcb911dbaa64e499254a6671a30';PROVIDER='AXCLRTExecutionProvider'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--max-new-tokens',type=int,default=256);p.add_argument('--think',action='store_true');p.add_argument('--question');a=p.parse_args();assert 1<=a.max_new_tokens<=1536
 root=a.model_dir.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);template_now=datetime.now().astimezone()
 mf=root/'.validation-download.json'
 if not mf.is_file():mf=Path(__file__).resolve().parent/'download-manifest.json'
 m=json.loads(mf.read_text());assert m['complete'] and m['revision']==REV and m['modelId']=='SmolLM3-3B';files={f['path']:f for f in m['files']}
 r=dict(modelId='SmolLM3-3B',revision=REV,provider=PROVIDER,completed=False,runnerSha256=sha(__file__),filesBefore=[],filesAfter=[],sessions=[],samples=[],totalCalls=0,embeddingMode='read-only NumPy mmap, unchanged float32 values',thinking=a.think,maxNewTokens=a.max_new_tokens)
 r['templateTimestamp']=template_now.isoformat()
 def save():(out/'deployment-result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
 def verify(key):
  for f in m['files']:
   digest=sha(root/f['path']);matched=digest==f['verifiedHashes']['sha256'];r[key].append(dict(path=f['path'],sha256=digest,matched=matched));save();assert matched,f['path']
 save();verify('filesBefore')
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false')
 import numpy as np,torch,axengine
 from ml_dtypes import bfloat16
 from transformers import AutoTokenizer
 import importlib.metadata as md
 torch.set_num_threads(2);np.random.seed(1234);r['versions']={k:md.version(k) for k in ['numpy','torch','transformers','tokenizers','ml-dtypes','tqdm']};assert PROVIDER in axengine.get_available_providers()
 live=[];Original=axengine.InferenceSession;sample=None
 def nodes(items):return [dict(name=n.name,shape=list(n.shape),dtype=str(n.dtype)) for n in items]
 class Session(Original):
  def __init__(self,path):
   name=Path(path).resolve().relative_to(root).as_posix();assert name in files
   self.audit=dict(model=name,sha256=files[name]['verifiedHashes']['sha256'],providerActual=PROVIDER,allFinite=True,runMilliseconds=[],groups={},calls=0);r['sessions'].append(self.audit);save();super().__init__(path,providers=[PROVIDER]);assert self.get_providers() in [PROVIDER,[PROVIDER]];live.append(self)
  def run(self,names,feed,shape_group=0):
   ins=self.get_inputs(shape_group=shape_group);outs=self.get_outputs(shape_group=shape_group);assert names is None
   if str(shape_group) not in self.audit['groups']:self.audit['groups'][str(shape_group)]=dict(inputs=nodes(ins),outputs=nodes(outs));save()
   assert set(feed)=={n.name for n in ins}
   for n in ins:
    v=feed[n.name];assert v.dtype==np.dtype(n.dtype),(n.name,v.dtype,n.dtype)
    if np.prod(n.shape)>0:assert tuple(v.shape)==tuple(n.shape),(n.name,v.shape,n.shape)
   t=time.perf_counter();values=super().run(names,feed,shape_group=shape_group);ms=1000*(time.perf_counter()-t);assert len(values)==len(outs)
   entry=dict(index=r['totalCalls'],sample=sample['name'] if sample else None,model=self.audit['model'],shapeGroup=shape_group,milliseconds=ms,outputs=[])
   for node,v in zip(outs,values):
    assert tuple(v.shape)==tuple(node.shape) and v.dtype==np.dtype(node.dtype);finite=bool(np.isfinite(v.astype(np.float32)).all());entry['outputs'].append(dict(name=node.name,shape=list(v.shape),dtype=str(v.dtype),sha256=hashlib.sha256(v.tobytes()).hexdigest(),allFinite=finite));assert finite,(self.audit['model'],node.name)
   with (out/'calls.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(entry)+'\n')
   self.audit['calls']+=1;self.audit['runMilliseconds'].append(ms);r['totalCalls']+=1
   if r['totalCalls']%100==0:save()
   return values
 axengine.InferenceSession=Session
 spec=importlib.util.spec_from_file_location('smollm3_official_infer',root/'utils/infer_func.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 cfg=SimpleNamespace(**json.loads((root/'smolvlm3_tokenizer/config.json').read_text()));assert cfg.hidden_size==2048 and cfg.num_hidden_layers==36
 tok=AutoTokenizer.from_pretrained(str(root/'smolvlm3_tokenizer'),local_files_only=True)
 embeds=np.load(root/'smollm3_axmodel/model.embed_tokens.weight.npy',mmap_mode='r');assert embeds.dtype==np.float32 and embeds.shape[1]==2048
 class TokenLimit(RuntimeError):pass
 try:
  t=time.perf_counter();im=mod.InferManager(cfg,str(root/'smollm3_axmodel'));r['loadSeconds']=time.perf_counter()-t;original_post=im.post_process
  def traced_post(logits,*args,**kwargs):
   token,candidates,probs=original_post(logits,*args,**kwargs);index=len(sample['generatedTokenIds']);logit_name=sample['name']+'-'+str(index).zfill(4)+'-logits.npz';np.savez_compressed(out/logit_name,logits=logits.astype(np.float32));row=dict(logitsFile=logit_name,logitsSha256=sha(out/logit_name),index=index,chosenTokenId=int(token),candidateTokenIds=[int(x) for x in candidates],candidateProbabilities=[float(x) for x in probs],millisecondsFromStart=1000*(time.perf_counter()-sample_started));sample['decisions'].append(row);sample['generatedTokenIds'].append(int(token));save()
   if int(token)!=tok.eos_token_id and index+1>=a.max_new_tokens:raise TokenLimit('Generation reached configured token limit without EOS')
   return token,candidates,probs
  im.post_process=traced_post
  prompts=[('arithmetic','2+3等于多少？只输出数字。'),('chinese','请用一句话说明 PCIe 的用途。'),('json','有3个苹果和2个梨。只输出JSON对象，键为apple和pear，值为数量，不要解释或代码块。')]
  if a.question:prompts=[('custom',a.question)]
  for name,question in prompts:
   for v in im.k_caches+im.v_caches:v.fill(0)
   messages=([dict(role='system',content='/no_think')] if not a.think else [])+[dict(role='user',content=question)]
   rendered=tok.apply_chat_template(messages,tokenize=False,add_generation_prompt=True,strftime_now=lambda fmt:template_now.strftime(fmt));ids=tok([rendered],return_tensors='pt').input_ids[0].numpy().tolist();assert len(ids)+a.max_new_tokens<im.max_seq_len
   assert len(ids)%128!=0,'Upstream exact-chunk boundary requires a separately reviewed fix'
   sample=dict(name=name,question=question,messages=messages,renderedPrompt=rendered,inputTokenIds=ids.copy(),generatedTokenIds=[],decisions=[],completed=False);r['samples'].append(sample);save();sample_started=time.perf_counter();error=None
   try:
    prefill=np.take(embeds,ids,axis=0).astype(bfloat16);tokens=im.prefill(tok,ids.copy(),prefill,slice_len=128)
    if tokens[-1]!=tok.eos_token_id:im.decode(tok,tokens,embeds,slice_len=128)
   except TokenLimit as ex:error=str(ex)
   sample['secondsIncludingTrace']=time.perf_counter()-sample_started;sample['naturalEos']=bool(sample['generatedTokenIds'] and sample['generatedTokenIds'][-1]==tok.eos_token_id);sample['response']=tok.decode(sample['generatedTokenIds'],skip_special_tokens=True);sample['firstTokenSeconds']=sample['decisions'][0]['millisecondsFromStart']/1000;sample['error']=error;sample['completed']=sample['naturalEos'] and error is None;save();print('\nSAMPLE_RESULT '+json.dumps({k:sample[k] for k in ['name','response','naturalEos','secondsIncludingTrace']},ensure_ascii=False),flush=True)
   sample.update(input=question,output=sample['response'],hitEos=sample['naturalEos'],stopReason='eos' if sample['naturalEos'] else 'limit');save()
   assert sample['completed'],error or 'Context boundary reached without EOS'
  r['inferenceCompleted']=True
 except BaseException:r['error']=traceback.format_exc();raise
 finally:
  save()
  for s in live:s._sess._unload();s.audit['unloaded']=True
  verify('filesAfter');save()
 r['completed']=True;save();print('Completed all SmolLM3 samples',flush=True)
if __name__=='__main__':main()
